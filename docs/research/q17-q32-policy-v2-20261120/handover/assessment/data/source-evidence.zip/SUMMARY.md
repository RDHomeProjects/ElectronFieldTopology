# Adaptive Q17–Q32 screening

{"utc": "2026-11-19T23:14:49.460514+00:00", "melbourne": "2026-11-20T10:14:49.460514+11:00"}

Status: **interrupted**.

{"q_values": 16, "declared_fresh_seed_variants": 34, "broad_bootstrapped_or_classified": 34, "broad_terminal": 34, "mesh_branches": 0, "domain_branches": 0, "motion_cases": 0, "maximum_optimizer_attempts": 11700, "spent_optimizer_attempts": 5725, "physical_Q_rejections": 0}

No Q sector is physically rejected; screen success is not long-time stability or electron acceptance.

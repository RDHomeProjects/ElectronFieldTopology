"""One-variable Maxwell pilot. Only step count changes; E measured at fixed T.
Uses the submitted Yee implementation after a documented AST instrumentation:
replace its step-count selection and return final E arrays for paired comparisons.
No GitHub interaction, original-source edits or scientific gate changes.
"""
import ast,csv,hashlib,json,sys,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import numpy as np
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'upload/evidence(20261113-114054).zip'
REPO=ROOT.parent/'rehearsal-newer'
CONFIG={'nodes':65,'axis':2,'phase':0.,'length':8.,'duration':.2,'steps':[12,18,24,36,48,72,96],'reference_steps':192,'training_steps':[12,24,48,96],'held_out_steps':[18,36,72],'response':'Electric-field relative L2 at T=.2 and finite-reference time sensitivity; B combined metric excluded because native B time changes with dt.'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp():
 t=datetime.now(timezone.utc);return {'utc':t.isoformat(),'melbourne':t.astimezone(ZoneInfo('Australia/Melbourne')).isoformat()}
(ROOT/'CONFIG.json').write_text(json.dumps(CONFIG,indent=2)+'\n')
with zipfile.ZipFile(SOURCE) as z:
 source=z.read('maxwell_yee_alignment.py');baseline=json.loads(z.read('study.json'))
assert hashlib.sha256(source).hexdigest()=='b1ad27cb811510a7dad139fad077187e09d0f290f74bba031f1ebbeb6bb3a328'
for name,h in baseline['source_sha256'].items():assert sha(REPO/'src/electron_field_topology'/name)==h
sys.path.insert(0,str(REPO/'src'));from electron_field_topology.fields import hopfion
# Adapt only instrumentation/step control; the curl and boundary implementation stay unchanged.
tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='case')
for node in fn.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='steps' for t in node.targets):node.value=ast.Name(id='FORCED_STEPS',ctx=ast.Load())
ret=next(n for n in reversed(fn.body) if isinstance(n,ast.Return));ret.value.keys.append(ast.Constant(value='_electric_fields'));ret.value.values.append(ast.Name(id='e',ctx=ast.Load()));ast.fix_missing_locations(tree)
ns={'__name__':'time_curve_instrumented'};exec(compile(tree,str(SOURCE),'exec'),ns)
(ROOT/'instrumented_yee.py').write_text(ast.unparse(tree)+'\n')
efields={};rows=[];start=stamp()
for steps in CONFIG['steps']+[CONFIG['reference_steps']]:
 ns['FORCED_STEPS']=steps;t=time.perf_counter();r=ns['case'](CONFIG['nodes'],CONFIG['axis'],CONFIG['phase'],'hopfion',hopfion,CONFIG['length'],CONFIG['duration']);elapsed=time.perf_counter()-t
 efields[steps]=r.pop('_electric_fields');row={'steps':steps,'dt':r['dt'],'electric_time':r['electric_time'],'electric_error_fraction':r['errors']['E_relative_l2'],'elapsed_seconds':elapsed,'role':'reference' if steps==CONFIG['reference_steps'] else 'training' if steps in CONFIG['training_steps'] else 'held_out'};rows.append(row);print(json.dumps({'recorded_at':stamp(),**row}),flush=True)
 if steps==12:assert r['errors']==next(c for c in baseline['cases'] if c['nodes']==65 and c['axis']==2 and c['phase']==0 and c['kind']=='hopfion')['errors']
points=[ns['points'](65,8.,o,2,0.) for o in ns['OFF_E']];masks=[np.all(abs(p)<=2,axis=-1) for p in points];den=sum(np.sum(hopfion(p,.2)[0][...,i][mask]**2) for i,(p,mask) in enumerate(zip(points,masks)));ref=efields[CONFIG['reference_steps']]
for row in rows:
 num=sum(np.sum((efields[row['steps']][i][mask]-ref[i][mask])**2) for i,mask in enumerate(masks));row['finite_reference_time_sensitivity_fraction']=float(np.sqrt(num/den))
result={'recorded_at':start,'finished_at':stamp(),'config':CONFIG,'baseline_archive_sha256':sha(SOURCE),'original_script_sha256':hashlib.sha256(source).hexdigest(),'instrumented_script_sha256':sha(ROOT/'instrumented_yee.py'),'source_sha256':baseline['source_sha256'],'python':sys.version,'numpy':np.__version__,'rows':rows,'scope':'New pilot on assistant host, not workstation production evidence. Only dt varies. Finite dt reference is not exact time convergence. Same prescribed analytical boundary, finite cube and phase. No optimal condition or new acceptance gate established.'}
(ROOT/'time-curve-data.json').write_text(json.dumps(result,indent=2)+'\n')
with (ROOT/'time-curve-data.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)

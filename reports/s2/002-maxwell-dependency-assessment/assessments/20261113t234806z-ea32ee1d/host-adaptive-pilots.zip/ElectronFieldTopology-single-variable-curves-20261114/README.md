# Matter Waves: single-variable curves before operating-condition selection

This package revises the experimental approach and includes completed fixed-seed and adaptive Maxwell pilots. Extract the ZIP and open adaptive-results/ADAPTIVE-REPORT.html for the latest adaptive study; REPORT.html retains the earlier curve comparison. Both reports are self-contained. Static high-resolution figures are included. No GitHub changes are made by this package.

## Decision

First identify conditional relationships by changing one numerical variable at a time. Fit and validate those relationships before choosing operating conditions. A fit describes a response under its fixed conditions; it does not alone establish causation, an asymptotic convergence order, or a physical optimum.

The earlier Maxwell grid refinement changed h and dt together. Its result describes coupled refinement and cannot separately identify the spatial and temporal contributions.

## Ordered studies

| Study | Vary | Hold fixed | Fit and decision |
|---|---|---|---|
| 1: temporal response | dt | grid, physical box, solver, field prescription, phase, direction, boundary prescription, final E measurement time | Compare linear, quadratic, exponential and justified power models; choose a tested range meeting the stated temporal-error budget |
| 2: spatial response | h | one dt chosen from study 1, physical box, solver, initial prescription, phase, direction, boundary, measurement time and physical assessment region | Fit error versus h; check that the fixed dt remains stable on every grid |
| 3: sampling | phase | h, dt, direction and all physical/numerical prescriptions | Use a periodic model, e.g. sine/cosine terms; preserve worst-case diagnostics |
| 4: boundary/domain | one domain-size or boundary-control parameter | h, dt, solver, field scale and fixed physical measurement region | Fit approach toward a stable response; do not vary boundary type and size together |
| 5: method comparison | categorical solver choice | matched physical problem, grid/time conventions where applicable, initial data, boundary and response | Repeat comparable controlled studies; do not treat solver labels as numbers in a polynomial |

Start with a small seed spread, then adapt measurement locations to the observed curve. Refine around turning points, possible inflections, model disagreement, residuals and declared tolerance crossings, while preserving coverage of the full range. Reserve fresh validation levels before adaptation and use the simplest adequately predictive model. See ADAPTIVE-PROTOCOL.md for selection, stopping and validation rules. Report coefficients with units, residuals and errors on withheld points. A small training residual or high R² alone is insufficient. Do not force an exponential fit or use high-degree interpolation just because it passes through the measurements.

After these individual studies, conduct a small targeted interaction check: for example, repeat the time-step curve at a second fixed grid. One-variable curves are conditional and do not rule out interactions. A change of initialization convention must be its own comparison.

## Completed pilot

The included pilot was run on the assistant host, not zbook. Receipt timestamps include UTC and Australia/Melbourne. It used the submitted Yee implementation with only step-count control and final-electric-field access instrumented. Curl and boundary formulas were retained. N=65, box side=8, phase=0, direction=z, E assessed at T=0.2. Analytical boundary values are imposed on the outer guard layers, and the diagnostic uses a fixed interior cube. This is a driven-boundary Maxwell validation, not an isolated-object evolution.

Training step counts: 12, 24, 48, 96. Withheld counts: 18, 36, 72. A separate 192-step finite reference is used only for the field-difference diagnostic. The 12-step errors reproduce the submitted benchmark exactly. Baseline source-file hashes are checked before execution.

Total E error over the seven fitted/validation runs is approximately 0.39438%–0.39648% and is nonmonotonic. For this response the quadratic had withheld RMSE 0.000007117 percentage points, versus about 0.000857 for linear/exponential models. In percent, the fitted relationship is

    error(dt) = 0.3933226383 + 0.6930526489*dt - 37.7736640*dt²

Use it only on the tested interval [0.0020833333, 0.0166666667] at this fixed configuration. It is an empirical response curve, not a continuum error law. The separately measured difference from the finite fine-step reference decreases as dt decreases; that reference is not exact temporal truth. Because the staggered magnetic startup is prescribed at -dt/2, its numerical initialization changes with dt. Its contribution remains to be separated before claiming a pure time-integration order.

No optimum has been established. A low total error can result from cancellation. Define accuracy, stability, conservation and cost objectives first; use the validated curves to identify a candidate admissible interval and confirm the selected condition in a fresh run. Step count is a work proxy. The included one-off elapsed times do not establish a workstation runtime model.

Maxwell electric-field L2 errors are separate from SF motion/speed criteria. Keep original acceptance gates, failed cases and topology qualifications. This pilot does not advance the SF scientific admission status.

## Files and optional local reproduction

time-curve-data.csv/json contain measurements; curve-fits.json contains coefficients, predictions and validation residuals. CONFIG.json records the preselected levels. executed-pilot.py and pilot.log preserve the original host run. run_time_curve.py is the path-configurable reproduction runner; instrumented_yee.py records the actual instrumented implementation. baseline-maxwell-evidence.zip is an unchanged copy of the supplied Maxwell evidence archive.

Reproduction requires the existing workstation checkout and its locked numpy/scipy/matplotlib dependencies. The runner checks fields.py and evolution.py against the supplied evidence, rejects an existing output path, and does not modify the checkout source or interact with GitHub. With `package` set to the extracted directory:

```bash
cd "$package"
sha256sum -c SHA256SUMS

repo="$HOME/ElectronFieldTopology-repository-admin"
out="$repo/artifacts/maxwell-single-variable/$(date -u +%Y%m%dT%H%M%SZ)"
cd "$repo"
uv run --frozen --python 3.12.14 python "$package/run_time_curve.py" \
  --repo "$repo" --output "$out"
uv run --frozen --python 3.12.14 python "$package/fit_curves.py" \
  --directory "$out"
xdg-open "$out/REPORT.html"
```

This is a study protocol and reproducible pilot, not a GitHub publication/update handover.

"""Bounded adaptive Maxwell pilot; one varying parameter, fixed final E time.

Reuses the supplied pilot data, adds six sequentially selected development
points, then measures three predeclared fresh validation points. Heuristic
scores guide sampling, not probabilistic confidence or scientific admission.
"""
import argparse, hashlib, json, sys, time
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import numpy as np

def stamp():
    t=datetime.now(timezone.utc)
    return {'utc':t.isoformat(),'melbourne':t.astimezone(ZoneInfo('Australia/Melbourne')).isoformat()}

def fit(rows):
    x=np.array([r['dt'] for r in rows]); y=np.array([r['electric_error_fraction'] for r in rows])
    scale=max(x); c=np.polynomial.polynomial.polyfit(x/scale,y,2)
    return c,scale

def select(rows,used,reserved):
    rows=sorted(rows,key=lambda r:r['dt']);x=np.array([r['dt'] for r in rows]);y=np.array([r['electric_error_fraction'] for r in rows])
    c,scale=fit(rows);span=x[-1]-x[0];yrange=max(np.ptp(y),1e-12)
    turn=-c[1]*scale/(2*c[2]) if abs(c[2])>1e-16 else None
    # Adjacent divided differences flag possible changes of concavity.
    # These are sampling targets, never inflection certificates.
    slopes=np.diff(y)/np.diff(x);curv=2*np.diff(slopes)/(x[2:]-x[:-2]);centres=x[1:-1]
    potential=[]
    for j in range(len(curv)-1):
        if curv[j]*curv[j+1]<0:
            potential.append(float((centres[j]+centres[j+1])/2))
    linear=np.polynomial.polynomial.polyfit(x/scale,y,1)
    options=[]
    for a,b in zip(x[:-1],x[1:]):
        available=[n for n in range(12,97) if n not in used and n not in reserved and a<.2/n<b]
        if not available: continue
        features=[]
        if turn is not None and a<turn<b and np.sum(abs(x-turn)<.15*span)<3:
            features.append(('turning_point',float(turn)))
        features.extend(('possible_inflection',p) for p in potential if a<p<b)
        target=features[0][1] if features else (a+b)/2
        n=min(available,key=lambda n:abs(.2/n-target));dt=.2/n
        disagreement=abs(np.polynomial.polynomial.polyval(dt/scale,c)-np.polynomial.polynomial.polyval(dt/scale,linear))/yrange
        # Gap width reduces the incentive to chase an already dense feature.
        score=(b-a)/span*(1+4*bool(features)+disagreement)
        options.append({'steps':n,'dt':dt,'bracket':[float(a),float(b)],'score':float(score),'reason':features[0][0] if features else 'coverage_and_model_disagreement','possible_inflection_targets':potential})
    if not options: raise RuntimeError('No remaining distinct candidate time steps')
    return max(options,key=lambda v:(v['score'],-v['steps']))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.home()/'ElectronFieldTopology-repository-admin')
    p.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=a.output.resolve()
    if root.exists():raise SystemExit('Output must be a new directory')
    root.mkdir(parents=True)
    data=json.loads((a.directory/'time-curve-data.json').read_text())
    for name,h in data['source_sha256'].items():
        if hashlib.sha256((a.repo/'src/electron_field_topology'/name).read_bytes()).hexdigest()!=h:raise RuntimeError('Source hash mismatch: '+name)
    instrumented=(a.directory/'instrumented_yee.py').read_bytes()
    if hashlib.sha256(instrumented).hexdigest()!=data['instrumented_script_sha256']:raise RuntimeError('Instrumented source hash mismatch')
    sys.path.insert(0,str(a.repo.resolve()/'src'))
    from electron_field_topology.fields import hopfion
    ns={'__name__':'adaptive_yee'};exec(compile(instrumented,'instrumented_yee.py','exec'),ns)
    # Original held-out points have already informed model comparison. They
    # remain in the evidence but are not labelled fresh validation here.
    rows=[dict(r) for r in data['rows'] if r['role']=='training']
    used={r['steps'] for r in data['rows']};reserved={15,30,60};journal=[]
    plan={'recorded_at':stamp(),'adaptive_points':6,'fresh_validation_steps':sorted(reserved),'reference_steps':192,'candidate_steps':[12,96],'quadratic_primary_model':'development-only local response model; no claimed physical law','score_rule':'interval width / full width * (1 + 4*feature flag + linear/quadratic spread / development response range)','feature_density_limit':'stop adding a turning-point bonus after three development points lie within 15% of full dt span','scope':'Only dt changes under the original staggered analytical startup prescription. Fresh validation is not used for adaptive choices.'}
    (root/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
    points=[ns['points'](65,8.,o,2,0.) for o in ns['OFF_E']];masks=[np.all(abs(v)<=2,axis=-1) for v in points]
    den=sum(np.sum(hopfion(v,.2)[0][...,i][m]**2) for i,(v,m) in enumerate(zip(points,masks)))
    ns['FORCED_STEPS']=192;reference=ns['case'](65,2,0.,'hopfion',hopfion,8.,.2).pop('_electric_fields')
    def measure(n,role):
        ns['FORCED_STEPS']=n;start=time.perf_counter();r=ns['case'](65,2,0.,'hopfion',hopfion,8.,.2);e=r.pop('_electric_fields')
        sensitivity=np.sqrt(sum(np.sum((e[i][m]-reference[i][m])**2) for i,m in enumerate(masks))/den)
        return {'recorded_at':stamp(),'steps':n,'dt':r['dt'],'electric_error_fraction':r['errors']['E_relative_l2'],'finite_reference_time_sensitivity_fraction':float(sensitivity),'role':role,'elapsed_seconds':time.perf_counter()-start}
    for k in range(plan['adaptive_points']):
        selection={'recorded_at':stamp(),'round':k+1,**select(rows,used,reserved)}
        # Persist the choice before performing the next numerical measurement.
        journal.append(selection);(root/'selection-journal.json').write_text(json.dumps(journal,indent=2)+'\n')
        r=measure(selection['steps'],'adaptive_development');rows.append(r);used.add(r['steps'])
        (root/'development.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'selection':selection,'measurement':r}),flush=True)
    c,scale=fit(rows)
    frozen={'recorded_at':stamp(),'model':'quadratic','coefficients_fraction_scaled_dt':c.tolist(),'dt_scale':scale,'development_steps':[r['steps'] for r in rows]}
    (root/'FROZEN-FIT.json').write_text(json.dumps(frozen,indent=2)+'\n')
    validation=[]
    for n in sorted(reserved):
        r=measure(n,'fresh_validation');r['predicted_error_fraction']=float(np.polynomial.polynomial.polyval(r['dt']/scale,c));r['residual_fraction']=r['electric_error_fraction']-r['predicted_error_fraction'];validation.append(r);print(json.dumps(r),flush=True)
    result={'plan':plan,'finished_at':stamp(),'original_receipt_sha256':hashlib.sha256((a.directory/'time-curve-data.json').read_bytes()).hexdigest(),'source_sha256':data['source_sha256'],'instrumented_script_sha256':data['instrumented_script_sha256'],'development':rows,'selections':journal,'frozen_fit':frozen,'fresh_validation':validation,'held_out_rmse_percentage_points':float(100*np.sqrt(np.mean([r['residual_fraction']**2 for r in validation]))),'scope':'Adaptive demonstration only; no inflection, optimum or new scientific admission certified. Old pilot held-outs are not fresh validation.'}
    (root/'adaptive-data.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'complete_pending_review','held_out_rmse_percentage_points':result['held_out_rmse_percentage_points'],'recorded_at':stamp()}),flush=True)

if __name__=='__main__':main()

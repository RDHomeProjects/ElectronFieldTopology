"""Fit predeclared training data and validate on held-out deterministic runs."""
import argparse,json,csv,io,html
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();root=a.directory
D=json.loads((root/'time-curve-data.json').read_text());rows=[r for r in D['rows'] if r['role']!='reference'];train=np.array([r['role']=='training' for r in rows]);hold=~train;x=np.array([r['dt'] for r in rows]);scale=max(x);z=x/scale
allfits={};fig,axes=plt.subplots(1,2,figsize=(13,4.6),layout='constrained');models=['linear','quadratic','second_order_offset','exponential']
for ax,response,label in zip(axes,['electric_error_fraction','finite_reference_time_sensitivity_fraction'],['Total electric-field error at fixed T','Difference from the finite fine-step reference']):
 y=100*np.array([r[response] for r in rows]);fits=[]
 for name in models:
  if name=='exponential':
   b0,a0=np.polyfit(z[train],np.log(y[train]),1);fit=least_squares(lambda c:np.exp(c[0]+c[1]*z[train])-y[train],[a0,b0],max_nfev=10000);c=fit.x
   pred=lambda t:np.exp(c[0]+c[1]*np.asarray(t)/scale)
   coefficients={'A':float(np.exp(c[0])),'B':float(c[1]/scale)};formula='y=A exp(B dt)'
  else:
   powers=[0,1] if name=='linear' else [0,1,2] if name=='quadratic' else [0,2]
   c=np.linalg.lstsq(np.stack([z[train]**i for i in powers],-1),y[train],rcond=None)[0]
   pred=lambda t:sum(v*(np.asarray(t)/scale)**i for v,i in zip(c,powers))
   coefficients={['a','b','c'][i]:float(v/scale**i) for v,i in zip(c,powers)};formula='y='+ '+'.join(f'{["a","b","c"][i]}'+('' if i==0 else '*dt' if i==1 else '*dt^2') for i in powers)
  predicted=pred(x);res=predicted[hold]-y[hold];rmse=float(np.sqrt(np.mean(res*res)));maxerr=float(np.max(abs(res)));grid=np.linspace(min(x),max(x),150);line=pred(grid)
  fits.append({'model':name,'formula':formula,'coefficient_units':'y in percent; dt in model time','coefficients':coefficients,'held_out_rmse_percentage_points':rmse,'held_out_max_abs_error_percentage_points':maxerr,'training_rmse_percentage_points':float(np.sqrt(np.mean((predicted[train]-y[train])**2))),'predictions':predicted.tolist(),'curve_dt':grid.tolist(),'curve_y_percent':line.tolist()})
  ax.plot(grid,line,label=name.replace('_',' '),lw=1.5,alpha=.85)
 ax.scatter(x[train],y[train],marker='o',s=43,color='#18324a',label='training (4)',zorder=5);ax.scatter(x[hold],y[hold],marker='D',s=45,color='#e39822',label='held out (3)',zorder=5)
 ax.set(title=label,xlabel='Time step Δt (model units)',ylabel='Relative L2 (%)');ax.grid(alpha=.2);ax.ticklabel_format(style='sci',axis='x',scilimits=(0,0));ax.legend(fontsize=7)
 allfits[response]=sorted(fits,key=lambda r:r['held_out_rmse_percentage_points'])
fig.suptitle('One-factor Maxwell pilot: grid, phase, field, box, boundary and E measurement time fixed',fontsize=11)
fig.savefig(root/'single-variable-curves.png',dpi=300);buf=io.StringIO();fig.savefig(buf,format='svg');svg=buf.getvalue();svg=svg[svg.index('<svg'):];plt.close(fig)
result={'fits':allfits,'training_steps':D['config']['training_steps'],'held_out_steps':D['config']['held_out_steps'],'fit_scope':'Deterministic empirical response curves on tested interval only. Held-out points selected before runs. No statistical confidence interval, extrapolated physical law, optimal condition or changed acceptance gate. Finite dt=0.2/192 reference is not exact temporal truth.'};(root/'curve-fits.json').write_text(json.dumps(result,indent=2)+'\n')
metrics=''
for response,fits in allfits.items():
 metrics+='<h3>'+html.escape(response)+'</h3><table><tr><th>Model</th><th>Held-out RMSE (percentage points)</th><th>Maximum held-out error (pp)</th></tr>'
 for r in fits:metrics+=f'<tr><td>{r["model"]}</td><td>{r["held_out_rmse_percentage_points"]:.7g}</td><td>{r["held_out_max_abs_error_percentage_points"]:.7g}</td></tr>'
 metrics+='</table>'
content='''<h1>Single-variable analysis and curve-based selection</h1><p>The earlier Maxwell h/dt refinement changed multiple numerical quantities together. This new pilot varies only the step count in the same Yee/analytical-boundary prescription. N=65, box side=8, phase=0, shift direction=z, E measurement T=0.2. B initialization remains at its required -dt/2 time; this prescribed startup depends on dt and may contribute to the observed time-step response.</p><p>Four fitting points (12/24/48/96 steps), three held-out points (18/36/72 steps), and one separate finite-reference run (192 steps) were specified before execution. The included pilot measurements were made on the assistant host, not the user's workstation; consult the receipt for subsequent local reproductions. The 12-step result exactly reproduces the uploaded benchmark.</p>'''
content+='<p>Recorded UTC: '+html.escape(D['recorded_at']['utc'])+'; Melbourne: '+html.escape(D['recorded_at']['melbourne'])+'.</p>'+svg+metrics
content+='''<h2>Interpretation</h2><p>The total field error is nonmonotonic. Choosing its smallest sampled value as an optimum could exploit cancellation rather than improve the method. The second response compares each final E field with the same finite fine-step reference, retaining field-vector differences before taking a norm. Its reference is approximate and not used as exact time convergence.</p><p>The usual second-order accuracy of the Yee update does not require this whole analytic-staggered-startup error curve at fixed h to be purely quadratic. A term associated with the dt-dependent startup convention is a candidate explanation to investigate, not a demonstrated cause. A subsequent startup comparison must hold all other choices fixed.</p><h2>Revised protocol</h2><ol><li>Specify one variable, fixed factors, measured response and operating objective before running.</li><li>Use at least six or seven preselected values; reserve validation values before fitting.</li><li>Compare a line, low-degree polynomial, exponential and a physically motivated power model; report held-out residuals and coefficient units. Phase is periodic and needs a periodic fit rather than extrapolated polynomials.</li><li>For time-step work, keep h, solver, initial-field prescription, geometry, boundary, alignment and the E measurement time fixed. For spacing work, first fix a sufficiently small dt and keep physical geometry and the analysis region fixed.</li><li>Compare SF methods only after each receives the same fixed-condition test. Do not simultaneously change method, phase and grid.</li><li>Select the least expensive admissible condition meeting separately specified accuracy, stability and conservation requirements, then test fresh conditions not used for fitting.</li><li>After individual relationships are established, use a small targeted interaction test. One-factor curves do not exclude interactions.</li></ol><p>Do not alter existing SF gates, call the Maxwell field error an SF speed error, extrapolate beyond tested ranges, or select a favorable alignment/mean as a replacement gate. The prior evidence remains unchanged; this is a pilot and protocol revision, not a new qualified production condition.</p>'''
(root/'REPORT.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Single-variable Maxwell pilot</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:32px auto;padding:0 20px;color:#18324a}svg{width:100%;height:auto}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left}table{border-collapse:collapse}h1,h2,h3{line-height:1.25}</style>'+content+'</html>')
for response,fits in allfits.items():print(response,[(r['model'],r['held_out_rmse_percentage_points']) for r in fits]);print('best',fits[0]['formula'],fits[0]['coefficients'])

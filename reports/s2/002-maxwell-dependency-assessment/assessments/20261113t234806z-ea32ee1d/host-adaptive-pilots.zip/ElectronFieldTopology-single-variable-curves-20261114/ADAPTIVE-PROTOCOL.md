# Adaptive intervals for single-variable studies

The measurement locations must respond to observed structure. Keep one variable active, but do not keep its measurement interval fixed. All other experimental controls remain fixed throughout the adaptive sequence.

1. **Cover the range.** Begin with a small spread of points, including both endpoints. Log the candidate range, response, fixed controls, numerical resolution, maximum additional points and decision tolerances before adaptation. Uniform spacing is optional; logarithmic spacing may suit variables spanning orders of magnitude.
2. **Fit provisionally.** Compare simple models with residuals and physical expectations. A linear or quadratic trend may suffice; an exponential must earn its use. For periodic phase use periodic models. Model disagreement is a diagnostic, not a calibrated probability interval.
3. **Choose the next interval from the evidence.** Prioritize a bracket containing a possible turning point, a sign change of estimated curvature, or a crossing of a predeclared accuracy limit. Also consider large residuals, disagreement between models and wide unsampled gaps. Add points on both sides of a suspected feature where feasible.
4. **Refine and recheck.** Measure the selected point, add it to development data, refit and choose again. Record every choice and its reason before taking its measurement. Reduce intervals near features; retain wider intervals where a simple model predicts adequately. Preserve some range coverage to avoid clustering all measurements at one feature.
5. **Stop by declared criteria.** End when feature brackets meet their location tolerance and prediction errors meet the declared response tolerance over successive rounds, or when the predeclared measurement budget is exhausted. Exhausting a budget means an incomplete refinement unless the tolerances also pass. This demonstration uses six additional points as a pilot budget; it does not claim full convergence.
6. **Validate separately.** Freeze the selected model before taking fresh validation measurements. Points that guided adaptive placement or model selection are development data. If fresh validation fails, retain the failure, resume development and reserve new validation points for the revised model.
7. **Choose operating conditions only afterwards.** Use a validated curve and explicit accuracy, stability, conservation and cost requirements. Measure the proposed condition directly. A local minimum of total error may reflect cancellation and is not automatically an optimal numerical setting.

## Inflection versus turning point

A turning point concerns a reversal of slope. An inflection concerns a change in concavity. A nondegenerate quadratic can have a turning point but has no inflection. Therefore a quadratic fit alone cannot locate an inflection. Suspected inflections need bracketing data supporting a change of curvature; do not force a higher polynomial degree merely to manufacture one. A local cubic or other suitable model may be investigated only when the number and placement of observations support it.

High curvature and a change of curvature sign are separate sampling triggers: curvature passes through zero at a smooth simple inflection, so selecting only the largest absolute curvature could miss it.

## Implemented bounded Maxwell demonstration

The sequential sampler reuses four original training points and excludes all original pilot measurements from its new-candidate pool. Three new validation counts (15, 30 and 60 steps) are reserved before the adaptive measurements and are not used for selection. Six development points are chosen sequentially from integer step counts 12–96, with dt=0.2/steps so final measurement time remains fixed. The original staggered analytical startup prescription is retained; its dependence on dt remains a qualification.

The primary model is the quadratic supported by the earlier pilot. Adjacent divided differences flag possible curvature sign changes. A turning-point bonus is limited once three development observations lie within 15% of the full dt span. A width-weighted score balances feature refinement, range coverage and linear/quadratic disagreement. This score is an explicit pilot heuristic, not a universal acquisition rule or statistical uncertainty estimate. See adaptive_time_curve.py and adaptive-results/PLAN.json for its exact definition.

No threshold-crossing trigger is activated in this pilot because a new accuracy budget has not been declared. No existing SF admission gate changes.

## Optional local reproduction

After extracting the package, set `package` to its absolute path, then use the existing locked workstation environment:

```bash
repo="$HOME/ElectronFieldTopology-repository-admin"
out="$repo/artifacts/maxwell-adaptive/$(date -u +%Y%m%dT%H%M%SZ)"
cd "$repo"
uv run --frozen --python 3.12.14 python "$package/adaptive_time_curve.py" \
  --repo "$repo" --directory "$package" --output "$out"
uv run --frozen --python 3.12.14 python "$package/render_adaptive.py" \
  --directory "$package" --results "$out"
xdg-open "$out/ADAPTIVE-REPORT.html"
```

The new measurements are produced locally. The supplied old receipt remains the baseline. Source hashes are checked, existing output directories are rejected, and no GitHub operation is performed.

# Finer follow-up options

UTC: 2026-11-08T01:48:14.439097+00:00; Australia/Melbourne: 2026-11-08T12:48:14.439097+11:00.

The local run writes followup.json with actual input/rest/moving hashes and stage-specific outcomes. The next handover can select h0.192/n121, h0.16/n145 or h0.12/n193 at the same L23.04. Use the coarse stationary field as a declared warm start only, freshly readmit the D4 action and restart matched motion from t0. Retain an original129-source-start control to test basin inheritance. If coarse topology/preparation fails, start the finer representation from the preserved original129 field. No finer computation is queued by this package. Longer duration, crossed directions and core-curve classification are separate optional follow-ups after reviewing the coarse result.

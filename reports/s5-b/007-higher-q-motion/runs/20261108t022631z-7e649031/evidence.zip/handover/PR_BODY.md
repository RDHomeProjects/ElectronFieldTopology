Prepare S5-B-007 as an inexpensive staged Q17/Q19 motion screen after merged PR61. Q1 correction is parked; its original 1.563660% speed failure remains recorded. Q2 physical-grid/domain work stays open and becomes the numerical fallback.

UTC: 2026-11-08T01:48:14.439097+00:00; Australia/Melbourne: 2026-11-08T12:48:14.439097+11:00.

- Short Q2/z reference first, beta=0.3 to T=0.2. An unsuccessful control skips higher-Q preparation/evolution.
- Recover only the three required hash-pinned original fields (~130 MB with HTTP Range), using existing Release catalogs. Full-part hash-checked fallback is bounded to required parts.
- Q17/Q19 rest grids 97³/h=0.24/L23.04, sampled at unchanged coordinates from original 129³/h=0.12 fields. Fresh unchanged-action D4 stationary readmission: at most four 50-iteration calls per candidate, including interrupted calls.
- Original boundary reserves and all motion criteria retained. Segments end T=0.05/0.1/0.2; recorded speed failure becomes stop-eligible at 0.1, other failed gates stop at the first segment. No automatic domain ladder or spatial refinement.
- Assess both coarse arms before optional same-grid dt=0.005 confirmations for full passes only. At most 140 moving steps. Two-dt consistency is not a measured convergence order.
- Original inputs, coarse rest/admitted/milestone/latest float64 fields, code/config hashes and runnable handover retained. followup.json supplies parent hashes and finer h=0.192/0.16/0.12 options with fresh readmission and motion reruns from t=0, including original-source-start controls for inherited basins.
- The release publisher supplies a descriptive title, measured outcomes, file guide and reproduction/restore instructions; original assets and earlier Releases remain unchanged.

Specification: `docs/models/SF-higher-q-screen.md`; ordering: ADR-0018; canonical roadmap and generated status/plans/indexes updated together. Existing numerical kernels and thresholds are unchanged; added code orchestrates recovery, preparation, observation and early decisions. One existing source-document generator sentence now follows the registered priority rather than hard-coding the old higher-Q ordering.

Read-only source probes retain positive coarse cell continuity and Hopf values within 5%. They are not stationary or moving-field results. The preparation record identifies the actual small software/recovery checks and test environment. Production outcomes await local execution and subsequent assessment.

Requirements: NUM-001/002/003, BND-001, REL-002, SCI-003/004, REP-001/002. AI-assisted implementation/preparation. Full new scientific fields are archived and independently download/hash verified before cleanup; no deletion is performed.

# Q17/Q19 coarse motion campaign — local handover

UTC: 2026-11-08T01:48:14.439097+00:00; Australia/Melbourne: 2026-11-08T12:48:14.439097+11:00.

This package parks Q1 correction and prepares a quick staged Q17/Q19 screen in the existing administrative checkout. Original Q1 results and all criteria are preserved. The prior analysis was merged as PR61; this preparation starts from main `73bce2144de270cf21a077a30f5ae35709447301` and creates branch `work/s5-b-007-coarse-higher-q`. Source kernels and old scientific records are unchanged.

## Start locally

```bash
(
set -euo pipefail
unzip -n "$HOME/Downloads/ElectronFieldTopology-Q17-Q19-screen-20261108.zip" \
  -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-Q17-Q19-screen-20261108"
bash "$package/INSTALL.sh"
bash "$package/PUBLISH.sh"
bash "$package/RUN.sh" start
)
```

INSTALL backs up the complete local Git history, creates the study branch, applies/stages the patch and runs essential checks with the frozen CPU Python 3.12.14 environment. Existing optional environment packages are retained during sync. It refuses tracked edits, active identified workers, unrelated branch content or an advanced main, preserving all work. A repeat exact install preserves staging/commits.

PUBLISH commits and uploads the preparation and opens/updates one study PR. **Keep that PR open while running and assessing the results.** It does not merge. RUN starts one background worker and prints its output/summary/evidence/log paths. Inputs are recovered automatically; no vanished old Home folder is required. Default checkout is `$HOME/ElectronFieldTopology-repository-admin`; add `--repo /absolute/checkout` to scripts if needed. For explicit retained sources, RUN supports `--source-map /path/map.json` with q2/q17/q19 keys; all file hashes must still match.

## What runs, and what stops early

| Stage | Default work | Early decision |
|---|---|---|
| Q2/z reference | Existing 127³/h=0.16/L20.16 field; beta=0.3; 20 steps | Failed preparation/control motion blocks higher-Q work |
| Q17/z and Q19/z preparation | 97³/h=0.24/L23.04; at most four 50-iteration calls each | Unresolved topology/preparation/boundary reserve skips that candidate |
| Q17/z and Q19/z coarse motion | beta=0.3, dt=0.01, T=0.2; 20 steps each | Original gates assessed at T=0.05/0.1/0.2; speed stop starts at 0.1 |
| Optional confirmation | dt=0.005, same grid/initial data/T=0.2; 40 steps | Only complete coarse passes, after both cheap arms; same early stops |

The original 1% speed/shape and 0.1% tail criteria remain. Initial and runtime safety reserves protect the tail criterion. Original flags are always retained, including the first short-window speed flag. Field coefficients, float64 precision and RK4 are unchanged. A coarse numerical/preparation failure is not a physical rejection of a Q value.

Planning estimate: **roughly 1–4 hours**, with early stops often shorter. Prior measured Q2 timings scale to about 22 minutes for all three initial trajectories plus another 21 minutes if both confirmations run, before new preparation/IO/assessment overhead. This is not a wall-time cap or guaranteed upper bound. At most 140 moving steps and bounded preparation are allocated. Inputs total about 130 MB through selective reads; a server without Range support may require individual 1 GiB fallback parts. Allow at least 16 GiB free for local results, archival and verification staging.

## Progress, stop and resume

```bash
bash "$HOME/Downloads/ElectronFieldTopology-Q17-Q19-screen-20261108/RUN.sh" status
bash "$HOME/Downloads/ElectronFieldTopology-Q17-Q19-screen-20261108/RUN.sh" stop
bash "$HOME/Downloads/ElectronFieldTopology-Q17-Q19-screen-20261108/RUN.sh" resume
```

Use stop/resume only when needed. Status reports process identity, heartbeat, current preparation/motion observations and exit receipt. Finished means `runner_alive:false`, an exit receipt with code 0, and status `complete_pending_review` or `complete_reference_blocked_pending_review`. Completion includes recorded failures; read SUMMARY.md. A stopped/error process alone does not mean the campaign finished. Every command writes UTC/Melbourne-stamped logs under this package's `logs/`; the numerical run retains its own runner.log.

## Send the completed results for assessment

```bash
(
set -euo pipefail
package="$HOME/Downloads/ElectronFieldTopology-Q17-Q19-screen-20261108"
bash "$package/PUBLISH.sh"
bash "$package/ARCHIVE.sh"
)
```

Alternatively `TRANSFER.sh` runs those two operations. PUBLISH appends compact results and updates the plan on the same PR. ARCHIVE uploads the complete run, original inputs, full fields and runnable handover using the existing verified archive engine, independently downloads/hashes all payloads and commits its Git catalog. It adds a human-readable release title, actual outcome table, file guide and reproduce/restore instructions while preserving scientific asset identities. It performs no local cleanup or deletion of older Releases. Keep the PR open for the scientific assessment handover.

Provide the generated evidence.zip and SUMMARY.md (paths shown by status), plus the terminal transcript or PR link. No rerun is required to transfer results. If a transfer is interrupted, retry that command; already uploaded identical assets are preserved and completed computation is retained.

## Finer follow-up without losing the coarse work

Original 129³ Q17/Q19 inputs, coarse pre/post-readmission states and full n/v at admitted/milestone/latest endpoints are retained. `followup.json` names parent hashes and conditional finer-grid choices: L23.04 at h=0.192/n121, h=0.16/n145 and h=0.12/n193, with longer windows/directions as justified. No fine run is automatically started. A new high-resolution calculation can reuse the coarse rest as a documented warm start, freshly readmit and rerun motion from t=0. Original-source-start controls avoid concealing inherited-basin effects, including the lesson from Q18. A coarse moving trajectory is not silently resumed on a different grid.

Q1 stays parked. If Q2 control fails or both higher-Q outcomes expose a common numerical issue, preserve the data and return to the registered Q2 method/convergence work. Failed coarsening/preparation can instead justify a finer original-source representation after assessment.

## Integrity and files

`study.patch`, PACKAGE.json and SHA256SUMS identify all changes. The new specification, ADR-0018, register, requirements and generated navigation align with the staged campaign. `VALIDATION.json` records real controls and the local handover rehearsal; remote operations in that rehearsal are mocked. The source-representation probe is read-only, and no production higher-Q optimizer/trajectory is run on the preparation host.

The installer backs up Git under `$HOME/EFT-admin-backups/s5-b-007/`. Local fields stay under `artifacts/s5-b/007-higher-q-motion/` in the one checkout. Safe recovery uses a separate clone of the backup bundle; no destructive reset or automatic path moves are supplied. Code/config/checkpoint mismatch stops with existing work retained. `VERIFY.sh` repeats essential integrity/link checks; it does not launch a production matrix.

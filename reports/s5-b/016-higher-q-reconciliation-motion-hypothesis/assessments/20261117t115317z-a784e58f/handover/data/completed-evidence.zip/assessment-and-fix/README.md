# Motion-probe assessment and linked-record completion

Open [ASSESSMENT.html](ASSESSMENT.html) for the reviewed Q2/Q8 outcomes and collection coverage findings. The original uniquely named evidence archive is valid; no simulation or previous diagnostic needs repeating.

The original collector selected canonical numbered study directories, but older measured records still reside at other paths explicitly registered in each study's records list. It therefore omitted 8 record entry points and 19 specification references (22 unique paths), including the actual Q22/Q18 assessment folders. This pack corrects document selection without changing numerical data, older published records, Git history or existing fields.

```bash
unzip -n "$HOME/Downloads/ElectronFieldTopology-reconciliation-assessment-and-record-fix-20261117.zip" \
  -d "$HOME/Downloads"

fix="$HOME/Downloads/ElectronFieldTopology-reconciliation-assessment-and-record-fix-20261117"

bash "$fix/RUN.sh"
```

This verifies the original evidence and reads the declared record directories, specifications and one level of local document links from the SAME pinned commit already in the local reconciliation checkout. It makes no GitHub request and performs no checkout, merge, relaxation, physical-time trajectory or full-field replay. Existing source evidence stays unchanged.

The output is a new uniquely named `ElectronFieldTopology-linked-reconciliation-…-evidence.zip` in Downloads. It contains the unchanged original evidence.zip plus the additional pinned documents, their hashes, a complete declaration-coverage ledger and explicit deferrals. Upload that new ZIP to finish the Q22/Q18 document reconciliation. The archive file limit is 8MiB, with 64MiB of supplemental content; large full-field/curve payloads are explicitly deferred. No archive assets are automatically downloaded.

Optional `--repo`, `--input` and `--output-parent` override paths. The input evidence hash and source commit remain fixed, so an unrelated evidence.zip is rejected. `--verify-only` verifies this pack without collection. All recorded events have UTC and Australia/Melbourne timestamps.

[VALIDATION.json](VALIDATION.json) records the local Git fixture, reference selection, source CSV preservation and checksum checks. The actual missing documents are collected only when this script runs on the zbook. The Q22 pilot remains conditional until their scientific findings are reviewed.

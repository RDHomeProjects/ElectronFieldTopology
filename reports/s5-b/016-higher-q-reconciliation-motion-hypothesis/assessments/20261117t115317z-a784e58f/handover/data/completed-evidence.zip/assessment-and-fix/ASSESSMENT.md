# Completed motion probes and Q22/Q18 reconciliation review

UTC: 2026-11-17T11:41:04.340866+00:00; Australia/Melbourne: 2026-11-17T22:41:04.340866+11:00.

## Outcome

The uniquely named evidence is the correct run 20261117t082634z-ee428350. Its 717 manifested payload hashes and ZIP CRCs pass, and the embedded handover matches the delivered package. The workstation log records PR 78 merged after three hosted checks. This published the preparation; the subsequently measured probe outcomes still require an assessment record.

The internal-rotation probe provides no useful rescue of the retained Q8 field. Q2 has a modest instantaneous improvement, but it already served as a near-stationary control. Neither result establishes that motion is necessary for physical stability. No relaxation or physical-time evolution ran.

## Measured effect of the fitted north-axis internal rotation

| Field | Fitted omega | RMS before → after | RMS reduction | Peak before → after | Peak change |
|---|---:|---|---:|---|---|
|Q2|0.0022889803|1.520323e-6 →1.462698e-6|3.7903%|6.636497e-5 →6.476660e-5|2.4085% lower|
|Q8|0.0001311802|2.049933e-5 →2.049933e-5|0.000000748%|0.0012090999 →0.0012091143|0.001194% higher|

The rates are fitted parameters of a frozen-field ansatz, not measured physical oscillation frequencies. The two fits are interior to the declared 0–0.05 range. The Q8 optimum is effectively near zero and brings a negligible RMS change while making the peak slightly worse. Its residual remains about 1.209 times the original static acceleration reference of 0.001. That comparison is descriptive; a dynamic residual does not replace the static gate or confer moving-field admission.

Increasing the assigned rate to 0.01 makes Q2's RMS about 5.03 times its zero-rate value and Q8's about 1.23 times; at 0.02 the factors are 20.57 and 3.01. This does not support allocating a larger frequency or finer frequency scan as a corrective step for these retained fields and this ansatz.

![Frozen-field residual curves](motion-balance.png)

Curves are reconstructed from the reported scalar samples and the qualified quadratic-in-rate operator, not new trajectories or independent field observations. Dots show reported scalar samples; crosses mark the fitted rates. The independent scalar reconstruction recovers the recorded optima to much less than 1e-8 in omega. It verifies arithmetic consistency, not physical stability.

## Numerical qualifications and RMS definitions

Both fields passed the recorded source/lock, field-hash, geometry, static replay and nonzero-rate CPU/array parity checks. Sign reversal of the assigned rate produced zero reported difference. Quadratic acceleration prediction errors were3.91e-14 for Q2 and 2.98e-14 for Q8; sphere-acceleration constraint errors were about 2.2e-15. These are instrument checks, not a new scientific stability criterion. The full fields were replayed on the workstation; they are not contained in this compact attachment and were not replayed here.

The probe RMS is the RMS vector norm over free nodes. The older stationarity report uses component RMS over the full grid. For an N-cubed box with two fixed layers on each face, their ratio is sqrt(3) times (N/(N−4))^(3/2). This exactly explains the observed factors 1.8172243 for Q2 and 1.8216288 for Q8. The apparent RMS mismatch is a definition difference, not evidence of inconsistent operators. Before/after comparisons above use the same probe definition throughout.

## What this says about motion

These measurements test uniform target-space rotation about the north axis, not spatial spinning, a genuine Lorentz boost, periodic deformation or an electromagnetic carrier. A modest reduction of an initial residual does not establish a stable orbit; failure to reduce it rejects only the attempted balance on the tested frozen field.

There is no new support for reopening Q8 continuation through assigned internal rotation. Q2 remains a reference, not a discovery that internal motion is required. Uniform translation remains a frame comparison under the continuum action, rather than an intrinsic stabilization cure. The previous distinction between massless neutral dynamics and the potential-bearing isospinning models remains important; see the unchanged [theoretical assessment](THEORY-CONTEXT.html).

For genuinely time-dependent candidates, the correct future question is whether the equations admit an appropriate relative or periodic solution with controlled localization, radiation and perturbation growth. A zero-rate stationarity test is not a universal exclusion theorem for that branch. Conversely, assigning velocity or spin to an unresolved static field is not evidence of such a solution. There is still no basis for a numerical percentage likelihood of motion-dependent stability or electron acceptance.

## Reconciliation is not yet document-complete

The export contains 687 selected Git files, including 41 historical source files, with no size-budget deferrals among the files selected. However, it did not follow all declared study record paths. The original collector used the new numbered study-directory prefixes; older measured reports remain at other registered paths.

Eight declared record entry points and 19 specification references are absent—22 unique paths in total. Most importantly, the actual Q22 assessment at reports/s5-a/q22-fresh-20261101T102757+1100/ASSESSMENT.md and Q18 assessment at reports/q18-neighbours/q18-neighbours-20261102T022100+1100-165739/ASSESSMENT.md are not in the export. The generic study indexes link to them but are not substitutes for their detailed findings. Some archive guides and observer/control specifications were also omitted. [MISSING-REFERENCES.json](MISSING-REFERENCES.json) lists every occurrence.

This is a collector scope error. It does not establish that the registered repository evidence is missing, and it is not a scientific failure. The wording “no deferred members” applies only to the selected files and must not be read as complete declared-record coverage. The supplied document-completion script follows those registered paths at the exact original source commit and reports coverage explicitly.

The four older Q22/Q18 checkpoint paths were also absent at their historical local locations. That existence check does not establish that the files were lost; previous verified archives may retain them. Their byte hashes remain recorded. No old Q22/Q18 full-field replay took place in this tranche, and no numerical rejection follows from their absence. Archive metadata should be read before deciding whether restoration is needed.

The available roadmap says Q22 has a bounded finite-topology benchmark assessment, and Q18 repeatedly produced a linked outcome with the target hyperbolic minimum still unreproduced. It also states that the Q18 fresh fine-start follow-up is planned, not completed. These summaries can guide the next questions, but the absent detailed reports are required before treating seed identity, numerical admission or reproduction gates as resolved.

## Next steps

1. Retain this completed negative Q8 balance result and the modest Q2 control effect. Preserve all gates, original fields and failed outcomes. Do not run another solver merely to regenerate the same diagnostic.
2. Run the provided read-only linked-record collector. It uses existing Git objects at dfcdd9ef3509cf0b3e6970986c8458d69f084b27, includes the original evidence unchanged, and creates one uniquely named supplemental ZIP. It makes no GitHub request, checkout change, relaxation, physical-time evolution or full-field restoration.
3. Review the recovered Q22/Q18 assessments, initial/final curve evidence, old-cell versus D4 distinctions and archive guides. Determine which existing results can serve as authenticated controls and what needs restoration or readmission.
4. Only then freeze the executable Q22 cable/link pilot's initial fields, grid, box, continuation criterion and resource qualification. The proposed 400-step cap remains a conditional contract, not an executed or fully specified campaign. Q18 remains secondary and the broad Q17–Q32 campaign remains deferred.

The immediate workstation task is document collection, not more simulation. This assessment and its tooling are AI assisted; no independent scientific peer review, physical stability proof or full-field backup is claimed.

"""Complete declared record references from the same local Git commit; never evolve fields."""
import argparse,csv,hashlib,html,json,posixpath,re,shutil,subprocess,sys,uuid,zipfile
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parent
EXPECTED_INPUT_SHA256='12d331160bff607d89250dc05811659aee11db5795b0ad1af4b9299de8c28893'
EXPECTED_COMMIT='dfcdd9ef3509cf0b3e6970986c8458d69f084b27'
def stamp():
 n=datetime.now(timezone.utc);return {'utc':n.isoformat(),'melbourne':n.astimezone(ZoneInfo('Australia/Melbourne')).isoformat()}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def event(message,**kw):print(json.dumps({'recorded_at':stamp(),'message':message,**kw}),flush=True)
def need(x,message):
 if not x:raise RuntimeError(message)
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.PIPE)
def safe(n):
 p=PurePosixPath(n);return bool(n) and not p.is_absolute() and '..' not in p.parts and n==p.as_posix()
def verify_package():
 seen=set()
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);need(safe(n) and n not in seen and sha(ROOT/n)==h,'Fix package differs: '+n);seen.add(n)
 actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'SHA256SUMS' and '__pycache__' not in p.parts};need(seen==actual,'Fix package coverage differs')
def collect_records(repo,head,studies,original_paths,out):
 tree={}
 for raw in git(repo,'ls-tree','-rlz',head).split(b'\0'):
  if not raw:continue
  meta,path=raw.split(b'\t',1);mode,kind,oid,size=meta.decode().split()
  if kind=='blob':tree[path.decode()]=(oid,int(size))
 declarations=[];roots=set();selected=set()
 for s in studies:
  for r in s.get('records',[]):
   n=r['path'];need(safe(n),'Unsafe declared record path');declarations.append({'study_id':s['id'],'role':r['role'],'path':n});selected.add(n)
   parent=PurePosixPath(n).parent.as_posix();need(parent not in ['.','reports','docs','data'],'Unexpected broad record root');roots.add(parent+'/')
  for n in s.get('specifications',[]):
   need(safe(n),'Unsafe specification path');declarations.append({'study_id':s['id'],'role':'specification','path':n});selected.add(n)
 selected.update(n for n in tree if any(n.startswith(prefix) for prefix in roots))
 # Include one level of direct local links from declared documents; do not crawl the entire project.
 for d in declarations:
  n=d['path']
  if n not in tree or not n.endswith('.md'):continue
  b=git(repo,'cat-file','blob',tree[n][0]).decode(errors='replace')
  for target in re.findall(r'\]\(([^)]+)\)',b):
   if '://' in target or target.startswith('#'):continue
   target=target.split('#',1)[0]
   linked=posixpath.normpath(posixpath.join(posixpath.dirname(n),target))
   if safe(linked) and linked in tree:selected.add(linked)
 inventory=[];used=0;cap=64*1024*1024
 declared_paths={d['path'] for d in declarations}
 for n in sorted(selected,key=lambda n:(n not in declared_paths,Path(n).suffix not in ['.md','.json','.csv','.py','.txt'],n)):
  item={'path':n}
  if n in original_paths:item['status']='already_in_original_verified_snapshot'
  elif n not in tree:item['status']='missing_from_pinned_git'
  else:
   oid,size=tree[n];item.update(git_blob=oid,bytes=size)
   if n.endswith(('.npz','.npy')):item['status']='deferred_full_field_or_curve_payload'
   elif size>8*1024*1024 or used+size>cap:item['status']='deferred_size_budget'
   else:
    b=git(repo,'cat-file','blob',oid);p=out/'repository'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);used+=len(b);item.update(status='copied',sha256=hashlib.sha256(b).hexdigest())
  inventory.append(item)
 lookup={x['path']:x['status'] for x in inventory}
 for d in declarations:d['status']=lookup[d['path']]
 return {'recorded_at':stamp(),'source_commit':head,'scope':'Record parents and explicit specifications from selected-studies.json; one level of local document links; original snapshot retained','references':declarations,'supplement_members':inventory,'new_bytes':used,'all_declared_references_present':all(d['status'] in ['copied','already_in_original_verified_snapshot'] for d in declarations),'deferred':[x for x in inventory if x['status'] not in ['copied','already_in_original_verified_snapshot']],'relaxation_steps':0,'physical_time_steps':0,'full_fields_replayed':False}
def seal(out,destination):
 files=sorted(p for p in out.rglob('*') if p.is_file() and p!=out/'SHA256SUMS')
 (out/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.relative_to(out).as_posix()+'\n' for p in files))
 with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
  for p in files+[out/'SHA256SUMS']:z.write(p,p.relative_to(out))
 with zipfile.ZipFile(destination) as z:need(z.testzip() is None,'Supplement ZIP CRC failure')
def main():
 p=argparse.ArgumentParser(description='Read-only document completion; no GitHub requests or numerical run')
 p.add_argument('--repo',type=Path,default=Path.home()/'ElectronFieldTopology-higher-q-reconciliation-20261117')
 p.add_argument('--input',type=Path,default=Path.home()/'ElectronFieldTopology-higher-q-reconciliation-20261117/artifacts/higher-q-reconciliation/20261117t082634z-ee428350/evidence.zip')
 p.add_argument('--output-parent',type=Path,default=Path.home()/'Downloads');p.add_argument('--verify-only',action='store_true');a=p.parse_args();verify_package()
 if a.verify_only:event('Assessment and document-completion pack verified');return
 a.repo=a.repo.expanduser().resolve();a.input=a.input.expanduser().resolve();a.output_parent=a.output_parent.expanduser().resolve()
 need(sha(a.input)==EXPECTED_INPUT_SHA256,'Input is not the reviewed uniquely named reconciliation evidence')
 with zipfile.ZipFile(a.input) as z:
  need(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'Original evidence CRC or duplicate failure')
  seen=set()
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1);need(safe(n) and n not in seen and hashlib.sha256(z.read(n)).hexdigest()==h,'Original evidence member differs: '+n);seen.add(n)
  need(seen|{'SHA256SUMS'}==set(z.namelist()),'Original evidence coverage differs')
  collection=json.loads(z.read('COLLECTION.json'));need(collection['source_commit']==EXPECTED_COMMIT,'Pinned source commit differs')
  studies=json.loads(z.read('selected-studies.json'));original={n[len('repository/'):] for n in z.namelist() if n.startswith('repository/')}
 git(a.repo,'cat-file','-e',EXPECTED_COMMIT+'^{commit}')
 rid=datetime.now(timezone.utc).strftime('%Y%m%dt%H%M%Sz-')+uuid.uuid4().hex[:8];name='ElectronFieldTopology-linked-reconciliation-'+rid;out=a.output_parent/name;out.mkdir(parents=True,exist_ok=False)
 event('Collecting linked documents from existing pinned Git objects',source_commit=EXPECTED_COMMIT,output=str(out))
 record=collect_records(a.repo,EXPECTED_COMMIT,studies,original,out)
 shutil.copy2(a.input,out/'original-evidence.zip');need(sha(out/'original-evidence.zip')==EXPECTED_INPUT_SHA256,'Copied original differs')
 shutil.copytree(ROOT,out/'assessment-and-fix',ignore=shutil.ignore_patterns('__pycache__'))
 record.update(original_evidence_sha256=EXPECTED_INPUT_SHA256,status='complete_pending_review' if record['all_declared_references_present'] else 'incomplete_declared_references')
 save(out/'REFERENCE-COVERAGE.json',record)
 (out/'REPORT.html').write_text('<!doctype html><html><meta charset="utf-8"><title>Linked reconciliation documents</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:30px auto;padding:20px}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style><h1>Linked reconciliation documents</h1><p>No solver, field replay, Git checkout change or GitHub request. Original evidence remains unchanged.</p><p><a href="assessment-and-fix/ASSESSMENT.html">Probe assessment</a></p><pre>'+html.escape(json.dumps(record,indent=2))+'</pre></html>')
 destination=a.output_parent/(name+'-evidence.zip');seal(out,destination)
 event('Linked-document evidence ready',status=record['status'],copied=sum(x['status']=='copied' for x in record['supplement_members']),deferred=len(record['deferred']),evidence=str(destination),sha256=sha(destination),relaxation_steps=0,physical_time_steps=0)
if __name__=='__main__':
 try:main()
 except Exception as e:event('Document completion stopped',error=str(e));sys.exit(1)

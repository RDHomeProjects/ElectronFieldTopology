"""Real local Git fixture: legacy record paths, specifications and explicit payload limits."""
from pathlib import Path
import tempfile,subprocess,json,sys
import collect_linked_records as c
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.PIPE).decode().strip()
checks=[]
with tempfile.TemporaryDirectory() as td:
 repo=Path(td)/'repo';repo.mkdir();git(repo,'init','-q');git(repo,'config','user.name','Fixture');git(repo,'config','user.email','fixture@example.invalid')
 data={'reports/s5-a/002-q22-benchmark/README.md':b'Index only\n','reports/s5-a/old-q22/ASSESSMENT.md':b'# Original assessment\n\n[Model](../../../docs/models/legacy.md)\n','reports/s5-a/old-q22/history.csv':b'iteration,energy\r\n1,2.5\r\n','docs/plans/q22.md':b'# Original plan\n','docs/models/legacy.md':b'# Original action\n'}
 for n,b in data.items():p=repo/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 (repo/'reports/s5-a/old-q22/large.bin').write_bytes(b'0'*(9*1024*1024));(repo/'reports/s5-a/old-q22/field.npz').write_bytes(b'not-to-be-copied')
 git(repo,'add','.');git(repo,'commit','-qm','fixture');head=git(repo,'rev-parse','HEAD');status=git(repo,'status','--porcelain')
 studies=[{'id':'s5-a-002','records':[{'role':'assessment','path':'reports/s5-a/old-q22/ASSESSMENT.md'}],'specifications':['docs/plans/q22.md']}];out=Path(td)/'output';out.mkdir()
 r=c.collect_records(repo,head,studies,{'reports/s5-a/002-q22-benchmark/README.md'},out)
 assert r['all_declared_references_present']
 assert (out/'repository/reports/s5-a/old-q22/ASSESSMENT.md').read_bytes()==data['reports/s5-a/old-q22/ASSESSMENT.md']
 assert (out/'repository/reports/s5-a/old-q22/history.csv').read_bytes()==data['reports/s5-a/old-q22/history.csv']
 assert (out/'repository/docs/plans/q22.md').is_file() and (out/'repository/docs/models/legacy.md').is_file()
 assert {x['status'] for x in r['deferred']}=={'deferred_size_budget','deferred_full_field_or_curve_payload'}
 assert git(repo,'rev-parse','HEAD')==head and git(repo,'status','--porcelain')==status
 checks+=['Registered legacy record folder collected even outside the numbered index directory','Record companion files, explicit specifications and one-level local model links included','Original bytes and CSV line endings preserved as source evidence','Large/full-field payloads explicitly deferred','Git HEAD and working-copy status unchanged']
 c.save(out/'REFERENCE-COVERAGE.json',r);target=Path(td)/'supplement.zip';c.seal(out,target)
 import zipfile,hashlib
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
 checks.append('Supplement archive CRC and manifested member hashes verified')
 r=c.collect_records(repo,head,[{'id':'fixture','records':[],'specifications':['docs/missing.md']}],set(),out)
 assert not r['all_declared_references_present'] and r['references'][0]['status']=='missing_from_pinned_git'
 checks.append('Missing declared entry point produces incomplete coverage rather than false success')
assert not c.safe('../outside') and not c.safe('/absolute') and c.safe('docs/a.md')
checks.append('Unsafe paths rejected')
for f in Path(__file__).parent.glob('*.py'):compile(f.read_text(),str(f),'exec')
result={'recorded_at':c.stamp(),'status':'passed','checks':checks,'limits':['Actual missing records must be read from the zbook pinned Git objects','No new scientific field replay, simulation or GitHub request performed here']}
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
else:print(json.dumps(result,indent=2))

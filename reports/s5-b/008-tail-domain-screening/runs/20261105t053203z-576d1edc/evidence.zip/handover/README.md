# Stationary tail-domain local handover — S5-B-008

Prepared UTC 2026-11-05T05:06:55.459022+00:00; Australia/Melbourne 2026-11-05T16:06:55.459022+11:00.

Sole aim: test potential corrective actions for the 0.1% outer-shell failure at L17.92 and L20.16. Q1/Q2 each receive both requested domains plus a contemporaneously readmitted L16 control: six stationary optimizations. This package does not run physical-time motion, beta sweeps, L24, new Q values, compression, charge or spin analysis. The original action, D4 functional, optimizer and all prior results remain unchanged.

## Run locally

Use the consolidated checkout at ~/ElectronFieldTopology-repository-admin. INSTALL.sh fetches/pins merged PR58 main, backs up complete Git history, creates work/s5-b-008-tail-domain and stages the additive patch. It preserves old branches and untracked artifacts. Repeated install of the exact preparation is safe. Unknown tracked edits or a changed GitHub baseline cause a stop without reset.

```bash
unzip -n "$HOME/Downloads/ElectronFieldTopology-tail-domain-20261105.zip" -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-tail-domain-20261105"
bash "$package/INSTALL.sh"
cd "$HOME/ElectronFieldTopology-repository-admin"
uv sync --frozen --all-groups --python 3.12.14
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 bash "$package/RUN.sh" test
bash "$package/RUN.sh" commit
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 bash "$package/RUN.sh" start
```

This uses CPU float64 and the existing D4 readmission action. The GPU cell-static solver is not interchangeable with it. No topology/GPU extras are needed for this test. Keep the workstation powered and awake.

The default read-only source is the retained original campaign:
`~/ElectronFieldTopology-lowq-motion/artifacts/lowq-motion-2026-11-03T104629-568611+1100-30672`.
Only its evidence ZIP and the Q1/Q2 n101/L16 stationary checkpoints are required; no original motion fields are loaded. Source SHA, shape, spacing, model, zero rate, fixed layers and original code maps are authenticated before launch. If the retained campaign has been restored elsewhere, append `--source /absolute/path/to/campaign` to start. A missing source stops before launching, with its path identified; it never silently substitutes a fresh field. The original complete GitHub archive is catalogued at data/archives/20261104t023917z-b0d06afa, root r031, if restoration is needed. Do not delete that cache during this experiment.

## Status, stop and resume

```bash
bash "$HOME/Downloads/ElectronFieldTopology-tail-domain-20261105/RUN.sh" status
bash "$HOME/Downloads/ElectronFieldTopology-tail-domain-20261105/RUN.sh" stop
# Wait until status reports runner_alive=false, then:
bash "$HOME/Downloads/ElectronFieldTopology-tail-domain-20261105/RUN.sh" resume
```

Status prints the exact output folder, current case, last optimizer iteration, heartbeat, summary/evidence paths and exit record. It does not need the initial shell environment variables: background defaults are OMP2/OpenBLAS1. A graceful stop retains an atomic latest checkpoint; a hard kill may require recomputing the most recent incomplete checkpoint interval. Optimizer conjugate memory resets on resume, as in the original readmission implementation; exact uninterrupted optimization paths are not claimed.

Finished means runner_alive=false, six recorded cases, final exit record and status **complete_pending_review** or **complete_with_unresolved_pending_review**. The latter is a completed diagnostic with unresolved stationarity/topology retained. A stopped process with error/stopped status is not completion. Completed run folders cannot be resumed or overwritten.

## What the test records

Lengths16/17.92/20.16 correspond to rest grids101/113/127 at spacing0.16. Each enlarged initial state exactly copies every original node into a centred north-vacuum extension; formerly fixed interior layers are freed. The initial measurement identifies the geometric effect of moving the shell. Every domain, including L16, is then readmitted using the unchanged optimizer with stricter preparation targets (relative force1e-4, acceleration1e-3); original thresholds remain separately reported. No tail penalty is minimized.

The original shell remains outer2 model-length units, with energy fraction limit0.001. Output includes absolute and fractional shell energies, Hamiltonian/continuum energy, fixed-coordinate cumulative tails, force/acceleration, topology/constraints, radii, centroid and integrated stress. Comparisons use fixed central73-cubed nodes and the original101-cubed footprint. Density derivatives are computed on full domains before cropping. No spatial or internal phase fit is used.

No box is automatically accepted for motion. An initial padding pass is not an equilibrated-field result; a final tail pass alone is not domain independence. The later assessment must compare qualification, fixed-region/core changes and both larger boxes. This is a warm-start continuation study, not an independent fresh-basin search. All failures are retained, and both requested sizes are attempted even if the smaller passes.

The output folder contains SUMMARY.md, tail-metrics.csv, comparisons.json, tail-domain.png, campaign/plan/inventory JSON, per-case optimizer history, initial/latest NPZ, logs, evidence.zip and an exit record. Compact evidence contains numerical metadata/analysis, not full fields. All reports, CSV rows, figure captions and result metadata have UTC/Melbourne timestamps.

## Runtime

There is no overall time/pass cap. The original readmission numerical topology/Armijo/stagnation rules remain. Earlier native n101 readmissions took about290–297seconds for50iterations. At equal iteration count, the113/127 grids have roughly1.4/2times the field volume. These new runs use stricter stationary targets, so iteration counts and total duration are uncertain; allow several hours and use heartbeat/iteration status. This is not another fixed-duration ten-hour trajectory run.

## After completion

```bash
package="$HOME/Downloads/ElectronFieldTopology-tail-domain-20261105"
bash "$package/PUBLISH.sh"
bash "$package/ARCHIVE.sh"
```

PUBLISH.sh records compact results in the canonical S5-B-008 run folder, updates the registry/navigation, commits/pushes this branch and opens/updates its PR using REST metadata. Failed cases remain published as unresolved. ARCHIVE.sh selects **only this new run** with the existing archive engine, uploads all new full fields/checkpoints/logs and a copy of this runnable handover to a Release, download-verifies them, registers the catalog and pushes that verification into the same PR. It does not upload the whole old cache again or delete anything locally.

Then copy evidence.zip and SUMMARY.md from the path printed by status into Downloads and attach them, together with publication/archive terminal output, for scientific assessment. Preserve the PR for that assessment. MERGE.sh is supplied for later explicit publication: it requires the registered verified full-field archive, clean matching heads and successful hosted checks. Merge is publication, not scientific acceptance.

No native six-case results are supplied in this package. VALIDATION.json records actual preparation controls and their limitations. Source/specification, requirements, provenance and exact decisions are in docs/models/SF-tail-domain-screening.md and the registered preparation record. The user-requested stationary screen now precedes the previously planned temporal audit; that audit and downstream Q studies remain in the plan.

Prepare S5-B-010: broaden from inherited high-Q targets to six fresh Q3/Q4/Q7 starts and conditional detailed neutral-field motion. Q2 is the short reference; Q1 stays parked; assessed Q17/Q19 preparation outcomes and every historical failure remain unchanged.

UTC: 2026-11-08T21:38:22.662797+00:00; Australia/Melbourne: 2026-11-09T08:38:22.662797+11:00.

- Q3 near-axial/bent starts, Q4 axial4,1/2,2 starts and Q7 axial/trefoil starts, with declared compact profiles and small deterministic symmetry breaking. Direct fresh D4 preparation avoids treating old cell-functional stationarity as time-lattice stationarity.
- Every coarse seed receives representation checks and up to six200-iteration preparation calls with strict original force/acceleration/topology/constraint gates. Native failures and consumed interrupted allocations remain. A bounded medium fresh retry addresses unresolved coarse preparation before expensive motion.
- All six coarse starts precede one detailed selected branch per Q:97/121/145 fixed-L23.04 meshes, fresh/warm controls, matched rest/motion tests, three fine-grid dt values, crossed-axis check and169³/L26.88 matched-spacing domain. Original case gates and tail reserves are unchanged; failures stop trajectories and incomplete/partial comparisons remain explicit.
- Full initial/latest/admitted/milestone fields, curves and native histories retained; separate post-run preview/replay commands do not change scientific arrays. Human-readable complete-field Release archive and verified Git catalog are required by the local merge helper.
- Actual preparation evidence: all six97³ seed representations and representative finer probes, recorded underresolved conditioning trial, authenticated selected Q2 source recovery, small numerical/controller/polygon checks, unchanged old kernels and additive handover rehearsals. No production Q3/Q4/Q7 relaxation/motion has run during preparation.

Scientific contract: `docs/models/SF-candidate-survey.md`; ADR-0020; targeted Sutcliffe2007/Hietarinta–Salo2000 source mapping and bibliography; sole roadmap/current status/plans/indexes updated together. Preparation record: `reports/s5-b/010-intermediate-q-survey/preparation/20261108t213822z-02554de8`.

Requirements SCI-003/004, SRCH-001/002, NUM-001/002/003/004, TOP-001, BND-001, REL-002, REP-001/002, VIS-001/002. AI-assisted design/implementation. Model/action/optimizer/RK4/old reconstruction and dependency locks remain byte-exact. New orchestration and read-only diagnostics do not establish a global minimum, isolated stability, electric charge or quantum spin.

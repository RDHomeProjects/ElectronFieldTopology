# Q3/Q4/Q7 workstation handover — continuation

10 November 2026, Australia/Melbourne. Exact UTC/AEDT validation times are in CONTINUATION-VALIDATION.json.

This resumes the proposed intermediate-Q campaign. The recovered implementation and scientific matrix are unchanged. The current main branch was checked at the package's pinned base, merged PR62, `8bf6cf4cd7d8b02eca141b306b5cbf959a4c78ed`. Fresh checks and this guide supplement the original preparation records; their older timestamps remain intact. The calculation has not been run here.

## Start on zbook

Save the supplied ZIP under its displayed filename in Downloads. Extract to the dated continuation directory so that a previous unpacked package cannot supply stale checksums:

```bash
set -euo pipefail
handover_dir="$HOME/Downloads/EFT-Q3-Q4-Q7-handover-20261110"
mkdir -p "$handover_dir"
unzip -n "$HOME/Downloads/ElectronFieldTopology-Q3-Q4-Q7-detailed-20261109.zip" -d "$handover_dir"
package="$handover_dir/ElectronFieldTopology-Q3-Q4-Q7-detailed-20261109"
(cd "$package" && sha256sum -c SHA256SUMS)
bash "$package/PREPARE.sh"
bash "$package/PUBLISH.sh" prepare
bash "$package/RUN.sh" preflight
bash "$package/RUN.sh" start
```

PREPARE uses `~/ElectronFieldTopology-repository-admin` unless EFT_REPO is set. It backs up Git history, installs the additive patch, synchronizes frozen dependencies and runs the relevant tests before committing locally. It preserves and reports unrelated work rather than resetting it. Git, gh and uv must be available, with the workstation's existing Git identity and GitHub authentication. PUBLISH prepare pushes the source and opens/reuses the study draft PR. No simulation is performed by either preparation or publication.

Start returns after launching a detached worker. Keep the computer awake and the checkout on the study branch. Do not change its code/config during the campaign. At least 60 GiB free initial headroom is required; allow additional room for successful full-field output and archive staging. The default is one sequential CPU float64 worker with two OpenMP threads and one BLAS thread. The older GPU cell optimizer is not a D4 solver. Runtime planning remains approximately 1–4 days if several candidates qualify, potentially longer; early failures may finish in hours. No overall runtime cap is imposed.

## Scientific allocation

| Work | Allocation |
|---|---|
| Q2 reference | Restore and hash-check the retained rest field; unchanged short motion reference |
| Q3 | Near-axial and bent starts, both with a small symmetry-breaking perturbation |
| Q4 | A(4,1) and A(2,2) starts |
| Q7 | Axial and rational-map trefoil starts |
| Preparation | Strict representation and stationarity gates; at most six 200-iteration calls per rest problem; native failures retained |
| Initial screen | 97 cubed, with one declared 121 cubed fresh retry per seed if neither coarse start at that Q becomes stationary |
| Detailed stage | One selected branch per qualified Q; 97/121/145 physical meshes, fresh/warm comparisons, three time steps, crossed-axis control and 169 cubed matched-spacing domain |

The original force, acceleration, energy, momentum, speed, shape, topology and boundary gates are unchanged. Failed or unresolved preparation is distinct from topology loss, rejected boost admission and failed motion. All competing starts and skipped cases remain recorded. The Q2 reference is checked before the candidate matrix; reference failure produces a blocked-reference result with explicit skips. Q1 stays parked; Q17/Q19 are not repeated. See README.md and docs/models/SF-candidate-survey.md after installation for the complete protocol and limitations.

## Progress, stop and resume

In a new terminal, re-establish the package path:

```bash
package="$HOME/Downloads/EFT-Q3-Q4-Q7-handover-20261110/ElectronFieldTopology-Q3-Q4-Q7-detailed-20261109"
bash "$package/RUN.sh" status
```

Status prints the exact run path, phase, latest observation, heartbeat and exit receipt. A finished calculation requires `runner_alive:false`, exit code `0`, and status `complete_pending_review` or `complete_reference_blocked`. Completion records the experiment; it does not imply that its candidates passed. An error/stopped state needs inspection or resume.

```bash
bash "$package/RUN.sh" stop
# Wait until status reports runner_alive:false.
bash "$package/RUN.sh" status
bash "$package/RUN.sh" resume
```

Do not use start to resume a stopped run: start creates a new record. Fields and checkpoints are retained. Full outputs are under the run path printed by status; SUMMARY.md and evidence.zip are produced there after calculation completion. Every result/receipt carries UTC and Australia/Melbourne timestamps.

## Return results for assessment

Provide the completed run's SUMMARY.md and evidence.zip for assessment, including a blocked-reference outcome. These compact files support initial assessment; detailed independent field analysis may require the complete retained states. Preserve the full run until its Release archive is verified.

The supplied local publication sequence is:

```bash
bash "$package/PUBLISH.sh"
bash "$package/ARCHIVE.sh" start
bash "$package/ARCHIVE.sh" status
# Wait for runner stopped, lifecycle complete, catalog and verification present.
bash "$package/MERGE.sh"
```

PUBLISH records compact evidence. ARCHIVE uploads only this new campaign, independently downloads and hash-verifies retained members, and registers a descriptive Release catalog. MERGE requires that catalog, matching asset identities and the exact checked PR head. These commands publish the numerical record; scientific assessment follows. No old results or Releases are deleted.

The handover evaluates neutral finite-box candidate preparation and controlled short motion. It contains no electromagnetic-charge or quantum-spin calculation and cannot establish an electron model from a successful trajectory.

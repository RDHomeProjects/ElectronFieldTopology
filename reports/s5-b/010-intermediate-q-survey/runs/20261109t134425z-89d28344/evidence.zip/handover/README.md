# Q3/Q4/Q7 detailed local simulation handover

UTC: 2026-11-08T21:38:22.662797+00:00; Australia/Melbourne: 2026-11-09T08:38:22.662797+11:00.

This package prepares **S5-B-010** in the existing `~/ElectronFieldTopology-repository-admin` checkout, from merged PR62/base `8bf6cf4cd7d8b02eca141b306b5cbf959a4c78ed`, on branch `work/s5-b-010-intermediate-q-survey`. It creates a verified Git-history backup before installation and preserves all old fields, results, paths and Releases. No production candidate solve or real GitHub write was performed while building this package.

## Start the detailed campaign

```bash
unzip -n "$HOME/Downloads/ElectronFieldTopology-Q3-Q4-Q7-detailed-20261109.zip" \
  -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-Q3-Q4-Q7-detailed-20261109"

bash "$package/PREPARE.sh"
bash "$package/PUBLISH.sh" prepare
bash "$package/RUN.sh" preflight
bash "$package/RUN.sh" start
```

PREPARE installs and checks the additive patch, synchronizes the existing frozen dependencies with Python3.12.14 through uv, runs the relevant small tests and commits the preparation **locally**. It refuses unrelated staged edits or a running research worker before switching branches. Repeating preparation verifies the known installed result; it never resets a branch or overwrites unknown work. INSTALL and VERIFY are separate wrappers if you prefer to inspect staged files before the local commit.

PUBLISH prepare pushes the committed source/plan and opens a **draft PR**, preserving the source remotely before the long calculation. Later publication reuses that PR. It remains draft until the full fields are verified and registered. Preflight authenticates and recovers only the retained Q2 input and checks resources. Start launches a detached worker and immediately returns the terminal. Keep this checkout on the prepared branch and do not edit its code/config while the worker runs; source/dependency changes are detected at subsequent phase checkpoints.

If the default checkout does not exist, PREPARE clones it. `EFT_REPO` can select a different clean checkout location. Existing artifacts remain in place. The local Git identity and authenticated gh session are used; no tokens or credentials are copied into the archive.

## What runs

| Phase | Work |
|---|---|
| Reference | Authenticated existing Q2 rest state; unchanged strict admission and short beta0.3/z/T0.2 motion |
| Fresh survey | Two starts each for Q3/Q4/Q7 on97³/h0.24/L23.04; strict preparation, then short motion where qualified |
| Bounded retry | If neither coarse start at a Q is stationary, its two analytic starts get one121³/h0.192 retry |
| Detailed preparation | One selected seed per Q;97/121/145 grids at fixed L23.04; fresh and warm starts at finer meshes |
| Detailed motion | RestT0.2 and beta0.3/z/T0.5 at each qualified mesh; finest-grid dt0.02/0.01/0.005 and x-axisT0.2 check |
| Domain | Selected fine parent extended at unchanged h0.16 to169³/L26.88, freshly readmitted and tested toT0.5 |
| Analysis records | Full native states, competing-start differences, matched-time/mesh/domain comparisons and two-target finite core diagnostics |

All old scientific limits remain: force1e-4, acceleration1e-3, shape/speed1%, energy/momentum0.1%, width2 tail0.1%, topology5%, unit/tangency1e-10. Stricter initial/predicted-coast/width3/runtime boundary reserves remain. All failed/skipped outcomes and native optimizer statuses are retained. A moving speed failure is recorded atT0.1 and becomes stop-eligible atT0.2; other original failures stop immediately. Partial common windows are retained without claiming fullT0.5 acceptance.

Each rest problem has up to six200-iteration calls; interruption consumes allocation. There is **no overall wall-time cap**. The CPU float64 D4 reference is used throughout; the older GPU cell-functional optimizer is not an equivalent substitute. Only qualified branches incur further detailed work. Seed conditioning is explicit and is not a change to model coefficients. Q1 remains parked.

Plan for **roughly1–4 days if several candidates qualify**, potentially longer when many preparation problems consume their full allocation; early failures can finish in hours. This is an estimate, not a cap. At least60GiB free initial headroom is required; leave additional space for a successful full matrix and temporary archive staging. A low-space guard retains checkpoints rather than deleting data.

## Check progress or stop safely

```bash
bash "$package/RUN.sh" status
bash "$package/RUN.sh" stop
# Wait until status reports runner_alive=false.
bash "$package/RUN.sh" resume
```

Status identifies the exact run, phase, current operation, latest preparation/motion observation, heartbeat, native error and exit receipt. Finished computation requires `runner_alive:false`, a matching exit code0 and status `complete_pending_review` or `complete_reference_blocked`; scientific failures can still be a correctly completed experiment. `evidence.zip` and `SUMMARY.md` are then available at the printed paths. A stopped/error run requires inspection/resume; it is not treated as successful completion. Finished runs are immutable; start creates a new record ID.

For live logs, use the path printed by start/status:

```bash
run="$(cat "$HOME/ElectronFieldTopology-repository-admin/artifacts/SF-CANDIDATE-SURVEY-CURRENT")"
tail -f "$run/runner.log"
```

Use Ctrl+C to exit tail; it does not stop the worker. `RUN.sh foreground` is available instead of start. The active checkout must remain available while computing. Every result and receipt includes UTC and Australia/Melbourne timestamps.

## Publish all results, retain all fields, then merge

After a completed run:

```bash
bash "$package/PUBLISH.sh"
bash "$package/ARCHIVE.sh" start
```

PUBLISH audits code/locks/compact evidence/checkpoint/curve seals, commits compact results into `reports/s5-b/010-intermediate-q-survey/runs/<record-id>`, updates the sole roadmap/navigation and reuses the study PR. It does not rerun the simulation or declare a scientific assessment complete.

ARCHIVE runs separately in the background and includes **only this complete new campaign**, not every old workstation folder. It uploads original inputs, all float64 rest/trajectory states, curves, histories and runnable handover as ordered Release segments; downloads/verifies every retained member; and pushes the descriptive guide/catalog into the same PR. Existing asset names with different bytes are never clobbered. No source data or old Release is removed.

```bash
bash "$package/ARCHIVE.sh" status
# If interrupted/error, preserve the log and resume the same session:
bash "$package/ARCHIVE.sh" resume
```

Archival is complete only when status reports the archive worker stopped, lifecycle state **complete**, and both catalog/verification present. Its release title identifies Q3/Q4/Q7; the description/RESEARCH-README explain measured outcomes, every file group, restore and reproducible calculation/analysis commands. Then:

```bash
bash "$package/MERGE.sh"
```

MERGE requires the verified catalog chain, unchanged remote asset identities, clean tracked work and the exact local PR head; it waits for required hosted checks and merges that head. It does not delete the branch or local fields. The result remains recorded pending scientific assessment. Source/environment/checksum integrity checks are separate from physical conclusions.

## Optional offline display and metric replay

Read `case-metrics.csv` to select an evolved case ID. After the solver finishes:

```bash
bash "$package/RUN.sh" preview --case CASE_ID
```

The printed path contains series.pvd. In ParaView: open it, Apply, select **Volume**, color by energy_density and reset the camera. The versioned `experiments/configs/renderers/candidate-survey.json` independently controls display grid/arrays/colors. The calculation uses full float64 arrays; the default display export is41³/Float32. Preview output is separate and rebuildable.

```bash
bash "$package/RUN.sh" replay --case CASE_ID
# Omit --case for the potentially expensive whole-run frozen-metric replay.
```

Replay writes a new separate receipt; it does not evolve or relax fields or alter the completed campaign. It authenticates the entire run first and re-evaluates retained full fields and comparisons, sharing the documented frozen instruments. These optional derived outputs do not enter the already immutable native run; register a separate assessment if publishing new analysis.

A researcher's restored run can be checked with `python3 scripts/check_candidate_survey.py --run RESTORED_RUN` and re-evaluated with `uv run --frozen --python 3.12.14 python -m electron_field_topology.sf_candidate_replay --run RESTORED_RUN --output NEW_REPLAY_FOLDER`, at the measured code commit. Native absolute provenance paths are mapped through the unchanged record ID, not rewritten.

## Package and recovery

- `study.patch`: all new code/config/tests, source review, ADR-0020, preparation evidence and generated current documentation.
- `PACKAGE.json`: pinned base, exact installed byte hashes, immutable code/preparation pins and navigation scope.
- `HANDOVER-VALIDATION.json`: actual installation/idempotence/guard and mocked remote-workflow rehearsal. Mocked writes are not hosted CI or production findings.
- `SHA256SUMS`: complete package checksum ledger.

Local command logs use `~/ElectronFieldTopology-admin-logs`, backups use `~/ElectronFieldTopology-admin-backups`, archive staging uses `~/EFT-archive-work`. Existing folders are reused. `EFT_LOG_DIR`, `EFT_BACKUP_DIR` and `EFT_ARCHIVE_WORK` can override them. The run and its archival lifecycle remain organized beneath the single checkout's artifacts tree. Clone the saved bundle into a different directory for inspection; never reset/delete an active research checkout. A published correction should be a new dated assessment or reviewed revert, preserving the old evidence.

AI assisted implementation, source mapping and preparation. No production candidate result, general isolated stability, unique final knot identity, electric charge or quantum spin is asserted by this handover.

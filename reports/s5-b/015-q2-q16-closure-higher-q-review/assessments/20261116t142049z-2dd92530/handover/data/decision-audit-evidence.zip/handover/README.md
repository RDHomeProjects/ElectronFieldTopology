# Final bounded decision audit — Q2 reference and retained Q8

The source/NumPy array-port audit completed here without a zbook run. HOST-REPORT.html and HOST-AUDIT.json state exactly what passed and what remains untested. The original retained-field and original CPU-module audit must run on the workstation because the uploaded compact evidence excludes full NPZ fields. No GitHub access, publication, dependency-lock change or broad Q scan is part of this package.

## Local audit and conditional comparison

```bash
unzip -n "$HOME/Downloads/ElectronFieldTopology-decision-audit-20261116.zip" -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-decision-audit-20261116"
(
  set -euo pipefail
  bash "$package/RUN.sh" verify
  bash "$package/RUN.sh" audit
  bash "$package/RUN.sh" compare --backend auto
  bash "$package/RUN.sh" status
)
```

Audit runs in the foreground on CPU. The comparison launches in the background only if the audit receipt permits it. If the audit is indeterminate, the comparison remains blocked and its evidence.zip is available for review. If an error stops the audit, provide the terminal/status output; do not delete or alter source fields.

Default checkout: `$HOME/ElectronFieldTopology-campaign2`. Q8 is resolved by the exact completed campaign2 evidence hash under its artifact directory. Q2 is the sealed reference under `$HOME/ElectronFieldTopology-repository-admin/artifacts/s5-b/010-intermediate-q-survey/20261109t134425z-89d28344`. Use `--repo`, `--q2-run`, `--q8-run` on audit/compare for relocated paths. Use a new `--output /absolute/path` on every numerical command for a separate allocation. Latest output is recorded under the checkout's `artifacts/final-decision-audit/CURRENT-20261116.json`.

## Read-only retained-field audit

Q2:127³,box20.16,checkpoint8772bde16a7301ac9d77ff04b8089da0324916a4795c2f99e797c96f24f9b930.
Q8:121³,box23.04,native750,checkpoint1c781889663026f12823e0d5a5c7b73f47c34a6fb37d75413456b69636fa0e4c.

The exact source and lock hashes, original compact archive hashes, fields, dtype, geometry and previous gate metrics must agree. Tests include original CPU versus the archived array implementation, the pointwise mass-weighted static-gradient/zero-velocity acceleration identity on active nodes, tangent and fixed-boundary treatment, a finite-variation epsilon sweep, and one disposable exact-CG descent/Armijo check. The audit reads the real skyrme.K constant from the local repository. Q2 must retain its static/tail reference pass. A missing/mismatched field, inconsistent operator, unqualified derivative or failed Q2 reference blocks the comparison.

The host tests use K=1 as an explicitly declared positive scalar normalization; this cancels in the consistency identity and relative variation checks. They execute exact hashed sf_time_gpu.py and seed source against a declared Grid scaffold. They do not execute the missing original CPU source or the zbook CUDA device. Fresh coarse Q-labelled maps are mathematical kernel tests, not retained candidates or exact topology certificates. In particular the coarse fresh-Q8 smoke map fails initial cone admission and its unconstrained energy reduction is NOT a scientific candidate result.

## One final method comparison

If the retained-field audit passes, both Q8 arms start from the same sealed750 field,121³ grid and23.04 box. Q2 remains read-only.

- Control: existing projected Sobolev-CG with its original retained optimizer state and alpha.
- Trial: independent SciPy L-BFGS, using the same static action and its exact sphere-retraction chain gradient. This is a solver-method comparison, not an isolated memory parameter test. It initializes its own curvature history.
- Maximum50 accepted steps per arm;100 new production steps total; L-BFGS at most200 value/gradient calls including its parameterization check.
- All original stationarity, representation and tail gates remain unchanged. Full CPU gate observations occur every5 accepted iterations and at termination; source fields remain byte-identical. Cone-invalid L-BFGS trial points receive an infeasible objective value and cannot constitute scientific success.
- Stop early on measured representation loss or strict stationarity. Passing stationarity while tail fails remains a boundary follow-up. No motion runs.

CPU works for the entire audit and comparison. `--backend auto` may use CUDA for both comparison arms after static-gradient and disposable continuation-step parity with CPU. The CPU still supplies gate metrics and gradient audits. `--backend cpu` forces CPU; `--backend cuda` stops if qualification is unavailable. There is no mid-arm fallback. Use four CPU threads,8GiB disk reserve and4GiB available host RAM reserve. Avoid concurrent EFT analysis jobs. No wall-time cap is imposed.

This comparison is deliberately finite. If the independent arm passes unchanged static/tail admission, it queues later refinement and motion admission. If not, record that this pipeline is not ready within the final declared audit and park unchanged continuation; this is not a physical rejection of Q8 or proof of model impossibility. No automatic rescue batches or further Q scan follow.

## Results and recovery

Status shows the output, heartbeat, runner.log and evidence paths. AUDIT.json records read-only tests; COMPARISON.json records the independent solver outcome. REPORT.html opens in a browser. Upload the final evidence.zip for assessment. Full final fields and original-CG optimizer state remain local with a hash manifest; preserve all parent fields.

There is no automatic resume of an interrupted L-BFGS comparison because its internal history is not checkpointed during callbacks. A partial comparison is preserved and cannot be overwritten by rerunning compare. Provide the partial output for review. Repeating compare after successful completion reports completion without launching another allocation. Ordinary audit and comparison outputs carry UTC and Australia/Melbourne timestamps.

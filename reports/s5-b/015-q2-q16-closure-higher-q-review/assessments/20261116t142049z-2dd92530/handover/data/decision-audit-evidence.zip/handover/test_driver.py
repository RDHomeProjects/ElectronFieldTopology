from pathlib import Path
import ast,sys,types,tempfile,json,time,shutil,zipfile
import numpy as np
from scipy.optimize import minimize
# Load the same saved production array port and declared Grid scaffold as the local source audit.
s=(Path(__file__).resolve().parent/'host_check.py').read_text();exec(s[:s.index('rng=np.random.default_rng')],globals())
packroot=Path(__file__).resolve().parent;sys.path.insert(0,str(packroot));import support
for name in ['sha','save','load','stamp','log','need','canonical']:globals()[name]=getattr(support,name)
# Execute the authentic original CG algorithm against the verified NumPy action oracle.
eft=types.ModuleType('electron_field_topology');eft.__path__=[];sys.modules[eft.__name__]=eft
sys.modules['electron_field_topology.skyrme']=sys.modules['verified_array.skyrme'];read=types.ModuleType('electron_field_topology.sf_readmission');read.static_value_gradient=port.static_value_gradient;sys.modules[read.__name__]=read
common=types.ModuleType('verified_array.common')
for name in ['canonical','sha','stamp','save']:setattr(common,name,globals()[name])
sys.modules[common.__name__]=common
engine=module('verified_array.engine',packroot/'source_arrays/engine.py');Engine=engine.Engine
from types import SimpleNamespace
original=ast.parse((packroot/'local_audit.py').read_text());functions=[x for x in original.body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and getattr(x,'name','') in ['projection','GateStop','classify','compare','report']]
g=Grid((17,)*3,(8.,)*3,'fixed');points=g.points();n=np.stack([.05*np.sin(points[...,0]),.03*np.cos(points[...,1]),np.ones(g.shape)],axis=-1);n=port.retract(n,np.zeros_like(n),g)[0]
def metrics(n,g):
 data,grad,acc=algebra(n,g);tangent=projector(n,grad)/(2*np.prod(g.spacing));return {'energy':data['energy_K1'],'relative_force_l2':float(np.linalg.norm(tangent)/np.sqrt(np.prod(g.shape))),'acceleration_max':float(np.max(np.linalg.norm(acc,axis=-1))),'minimum_corner_cone':cone(n),'hopf_integral':-8.,'unit_error':float(np.max(abs(np.linalg.norm(n,axis=-1)-1))),'tail_fraction':0.}
def representation(m,q,p):return m['minimum_corner_cone']>0 and m['unit_error']<1e-10
def stationary(m,q,p):return representation(m,q,p) and m['relative_force_l2']<=1e-4 and m['acceleration_max']<=1e-3
namespace=globals().copy();namespace.update(ROOT=packroot,a=SimpleNamespace(backend='cpu'),GATES={},identity=lambda:{},verify_sources=lambda:None,field=lambda key:(n.copy(),g),read_q8_state=lambda e:e.state(n.copy()),checkpoint=engine.checkpoint,metric=metrics,static_value_gradient=port.static_value_gradient,guard=lambda:None,projection=lambda n,x:x-n*np.sum(n*x,axis=-1,keepdims=True),K=1.,log=lambda *args,**kw:None)
exec(compile(ast.Module(body=functions,type_ignores=[]),'actual-decision-driver-under-test','exec'),namespace)
with tempfile.TemporaryDirectory() as td:
 out=Path(td);namespace['out']=out;save(out/'AUDIT.json',{'identity':{},'comparison_allowed':True});(out/'AUDIT.sha256').write_text(sha(out/'AUDIT.json')+'\n');namespace['compare']();r=load(out/'COMPARISON.json');assert len(r['results'])==2 and all(v['accepted_steps']<=50 for v in r['results'])
 for v in r['results']:assert v['metrics']['energy']<=metrics(n,g)['energy'];assert (out/v['method']/'final.npz').exists()
 with zipfile.ZipFile(out/'evidence.zip') as z:
  for line in z.read('SHA256SUMS').decode().splitlines():
   h,name=line.split('  ',1);assert __import__('hashlib').sha256(z.read(name)).hexdigest()==h
 receipt={'status':'driver_host_test_passed','recorded_at':stamp(),'results':[{'method':v['method'],'accepted_steps':v['accepted_steps'],'status':v['status'],'energy':v['metrics']['energy']} for v in r['results']],'scope':'Actual comparison driver, authentic CG algorithm and SciPy L-BFGS run against the saved array-port action on a small smooth synthetic field. Q label in metric fixture is synthetic; no retained candidate or Hopf qualification is implied.'};print(json.dumps(receipt,indent=2))

"""Retained-field decision audit, local workstation only; no GitHub access."""
import argparse,sys,os,time,zipfile,shutil,traceback,threading,signal
from pathlib import Path
from support import *
p=argparse.ArgumentParser();p.add_argument('mode',choices=['audit','compare']);p.add_argument('--repo',type=Path,required=True);p.add_argument('--q2-run',type=Path,required=True);p.add_argument('--q8-run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--backend',choices=['cpu','auto','cuda'],default='cpu');a=p.parse_args();repo=a.repo.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(repo/'src'))
import fcntl
lock=(out/'worker.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
import numpy as np
from scipy.optimize import minimize
from electron_field_topology import sf_time as cpu
from electron_field_topology.sf_time_gpu import ArrayTime
from electron_field_topology.sf_readmission import static_value_gradient,stationarity
from electron_field_topology.sf_temporal_metrics import tail_band
from electron_field_topology.skyrme import K
from electron_field_topology.rapid_q_screen.engine import Engine,checkpoint
from electron_field_topology.rapid_q_screen.policy import representation,stationary
ANCHORS=load(ROOT/'ANCHORS.json');GATES=load(ROOT/'GATES.json');roots={'Q2':a.q2_run.resolve(),'Q8':a.q8_run.resolve()}
def projection(n,v):return v-n*np.sum(n*v,axis=-1,keepdims=True)
def guard():
 need(shutil.disk_usage(out).free>8*1024**3,'Disk reserve below8GiB')
 available=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))/1024**2;need(available>=4,'Available host RAM reserve below4GiB')
def identity():return {'package_sha256':verify_package(),'repo':str(repo),'q2_run':str(roots['Q2']),'q8_run':str(roots['Q8']),'source_sha256':load(ROOT/'SOURCE.json')}
def verify_sources():
 for n,h in load(ROOT/'SOURCE.json').items():need((repo/n).is_file() and sha(repo/n)==h,'Source/lock differs: '+n)
 for key,root in roots.items():
  ref=ANCHORS[key];need(sha(root/'evidence.zip')==ref['archive_sha256'],'Wrong '+key+' archive');path=(root/ref['checkpoint']).resolve();need(path.is_relative_to(root) and sha(path)==ref['checkpoint_sha256'],'Wrong '+key+' retained field')
def field(key):
 ref=ANCHORS[key];path=roots[key]/ref['checkpoint']
 with np.load(path,allow_pickle=False) as z:n=z[ref['field_key']].copy()
 need(n.dtype==np.float64 and np.isfinite(n).all() and n.shape==(ref['nodes'],)*3+(3,),'Invalid '+key+' field');g=cpu.Grid((ref['nodes'],)*3,(ref['length'],)*3,'fixed');return n,g
def metric(n,g):return {**stationarity(n,g),'tail_fraction':tail_band(n,np.zeros_like(n),g,2.)['fraction']}
def verify_metric(key,m):
 for k,v in ANCHORS[key]['expected_metrics'].items():
  if isinstance(v,(int,float)) and k in m:need(np.isclose(m[k],v,rtol=1e-9,atol=1e-12),'Retained metric replay differs: '+key+' '+k)
def fd_check(n,g,gradient):
 d=-projection(n,gradient);d[g.fixed_mask()]=0;size=np.linalg.norm(d);need(size>1e-30,'Zero gradient: finite variation indeterminate');d/=size;analytic=float(np.sum(gradient*d));rows=[]
 for eps in [.1,.03,.01,.003,.001,.0003]:
  plus=cpu.retract(n+eps*d,np.zeros_like(n),g)[0];minus=cpu.retract(n-eps*d,np.zeros_like(n),g)[0];value=(static_value_gradient(plus,g)[0]-static_value_gradient(minus,g)[0])/(2*eps);rows.append({'epsilon':eps,'numerical':value,'absolute_error':abs(value-analytic),'relative_error':abs(value-analytic)/max(abs(analytic),1e-30)})
 best=min(rows,key=lambda x:x['relative_error']);return {'analytic':analytic,'sweep':rows,'best':best,'passed':best['relative_error']<=1e-3}
def read_q8_state(e):
 path=roots['Q8']/ANCHORS['Q8']['checkpoint']
 with np.load(path,allow_pickle=False) as z:
  s={k:float(z[k]) if k=='alpha' else int(z[k]) for k in ['alpha','iteration','next_observe','observe_spacing']}
  for k in ['n','old_g','old_z','direction']:s[k]=e.xp.asarray(z[k]).copy() if z[k].size else None
 return s

def run_audit():
 verify_sources()
 if (out/'AUDIT.json').exists():
  need(sha(out/'AUDIT.json')==(out/'AUDIT.sha256').read_text().strip(),'Changed audit receipt');need(load(out/'AUDIT.json')['identity']==identity(),'Audit identity differs');log('Existing matching audit retained',output=str(out));return
 results=[];port=ArrayTime(np)
 for key in ['Q2','Q8']:
  guard();log('Auditing retained field',field=key);n,g=field(key);m=metric(n,g);verify_metric(key,m);nn=cpu.retract(n,np.zeros_like(n),g)[0];energy,grad=static_value_gradient(nn,g);pe,pg=port.static_value_gradient(nn,g)
  need(np.isclose(energy,pe,rtol=2e-10,atol=2e-11) and np.allclose(grad,pg,rtol=2e-10,atol=2e-11),'CPU/array objective mismatch')
  acc=cpu.acceleration(nn,np.zeros_like(nn),g)[1];pa=port.acceleration(nn,np.zeros_like(nn),g)[1];need(np.allclose(acc,pa,rtol=2e-9,atol=2e-10),'CPU/array acceleration mismatch');del pg,pa
  d=cpu.gradients(nn-np.array([0.,0.,1.]),g);mass=(1+np.sum(d*d,axis=(-2,-1)))[...,None,None]*np.eye(3)-np.einsum('...ia,...ib->...ab',d,d);rhs=projection(nn,grad)/(2*K*np.prod(g.spacing));residual=projection(nn,np.einsum('...ab,...b->...a',mass,acc))+rhs;residual[g.fixed_mask()]=0;scale=max(float(np.max(abs(rhs))),1e-30);relative=float(np.max(abs(residual)))/scale
  need(relative<=2e-8,'Mass-weighted static/dynamic operator identity differs');fd=fd_check(nn,g,grad)
  item={'field':key,'metrics':m,'mass_gradient_identity_relative_error':relative,'mass_gradient_identity_max_error':float(np.max(abs(residual))),'CPU_array_energy_difference':abs(energy-pe),'finite_variation':fd,'representation_admitted':representation(m,int(key[1:]),GATES),'static_and_tail_pass':stationary(m,int(key[1:]),GATES) and m['tail_fraction']<=.00075};results.append(item);save(out/'audit-progress.json',results);del n,nn,d,mass,acc,grad,rhs,residual
 engine=Engine('cpu');s=read_q8_state(engine);n=s['n'].copy();g=cpu.Grid((121,)*3,(23.04,)*3,'fixed');e0,grad=static_value_gradient(n,g);accepted,step=engine.step(s,g);descent={'disposable':True,'accepted':accepted,'step':step}
 if accepted:
  direction=s['direction'];slope=float(np.sum(grad*direction));energy=static_value_gradient(s['n'],g)[0];descent.update(energy_before=e0,energy_after=energy,prestep_directional_derivative=slope,alpha=s['alpha']);need(slope<0 and energy<=e0+1e-4*s['alpha']*slope+1e-13,'Actual CG descent/Armijo inconsistency')
 verify_sources();allowed=all(v['finite_variation']['passed'] and v['representation_admitted'] for v in results) and results[0]['static_and_tail_pass'] and accepted
 receipt={'recorded_at':stamp(),'status':'audit_passed' if allowed else 'audit_indeterminate_comparison_blocked','identity':identity(),'fields':results,'disposable_CG_step':descent,'comparison_allowed':allowed,'limits':'Full-field replay on local CPU; no new physical acceptance and no production relaxation during audit'};save(out/'AUDIT.json',receipt);(out/'AUDIT.sha256').write_text(sha(out/'AUDIT.json')+'\n');report(receipt)
 log('Retained-field audit finished',status=receipt['status'],output=str(out))

class GateStop(Exception):pass
def classify(m):
 if not representation(m,8,GATES):return 'representation_failed'
 if stationary(m,8,GATES):return 'strict_static_survivor_pending_mesh_confirmation' if m['tail_fraction']<=.00075 else 'stationary_boundary_followup'
 return 'unresolved'
def compare():
 need(sha(out/'AUDIT.json')==(out/'AUDIT.sha256').read_text().strip(),'Changed audit receipt');receipt=load(out/'AUDIT.json');need(receipt['identity']==identity(),'Audit identity changed')
 if not receipt['comparison_allowed']:log('Comparison blocked by audit outcome',output=str(out));return
 
 if (out/'COMPARISON.json').exists():log('Comparison already complete',output=str(out));return
 verify_sources();n,g=field('Q8');engine=Engine('cpu');backend={'selected':'cpu','requested':a.backend}
 if a.backend!='cpu':
  try:
   trial=Engine('cuda');trial.audit(trial.xp.asarray(n),g);cs=read_q8_state(engine);gs=read_q8_state(trial);ca=engine.step(cs,g)[0];ga=trial.step(gs,g)[0];trial.sync();need(ca==ga and np.allclose(engine.host(cs['n']),trial.host(gs['n']),rtol=2e-9,atol=2e-10),'CPU/CUDA retained continuation-step parity failed');del cs,gs;backend={'selected':'cuda','requested':a.backend,'identity':trial.port.identity()};engine=trial
  except Exception as ex:
   if a.backend=='cuda':raise
   backend['CUDA_unavailable_or_rejected']=str(ex)
 save(out/'backend.json',backend);results=[]
 for method in ['CG-control','LBFGS-trial']:
  folder=out/method;folder.mkdir(exist_ok=False);history=[{'recorded_at':stamp(),'iteration':0,**metric(n,g)}];last=[n.copy()];counter=[0];last_x=[n.ravel().copy()];status=['unresolved'];calls=[0]
  def observe(field,iteration):
   m=metric(field,g);engine.audit(engine.xp.asarray(field),g);history.append({'recorded_at':stamp(),'iteration':iteration,**m});save(folder/'history.json',history);save(out/'status.json',{'recorded_at':stamp(),'status':'comparing','method':method,'accepted_steps':iteration});log('Audit comparison observation',method=method,iteration=iteration,force=m['relative_force_l2'],acceleration=m['acceleration_max']);status[0]=classify(m)
   if status[0]!='unresolved':raise GateStop(status[0])
  start_energy=static_value_gradient(n,g)[0];solver_message=''
  try:
   if method=='CG-control':
    s=read_q8_state(engine)
    for i in range(1,51):
     guard();accepted,step=engine.step(s,g)
     if not accepted:solver_message=step.get('reason','step rejected');break
     counter[0]=i;last[0]=engine.host(s['n']);last_x[0]=last[0].ravel().copy()
     if i%5==0:observe(last[0],i)
    solver_message=solver_message or 'Declared50-step cap reached'
   else:
    shape=n.shape;mask=g.fixed_mask()
    def fg(flat):
     guard();calls[0]+=1
     if calls[0]>200:raise GateStop('Declared L-BFGS evaluation budget reached')
     x=flat.reshape(shape);size=np.linalg.norm(x,axis=-1,keepdims=True)
     if not np.isfinite(size).all() or size.min()<1e-12:return 1e100,np.zeros_like(flat)
     field=x/size;field[mask]=[0.,0.,1.]
     if engine.cone(engine.xp.asarray(field))<=0:return 1e100,np.zeros_like(flat)
     value,raw=engine.value(engine.xp.asarray(field),g);raw=engine.host(raw);chain=projection(field,raw)/size;chain[mask]=0;return float(value),chain.ravel()
    # Qualify the actual independent parameterization at the retained field.
    f0,chain=fg(n.ravel());direction=chain.copy();direction/=max(np.linalg.norm(direction),1e-30);eps=.03;num=(fg(n.ravel()+eps*direction)[0]-fg(n.ravel()-eps*direction)[0])/(2*eps);ana=float(np.dot(chain,direction));need(abs(num-ana)<=1e-3*max(abs(ana),1e-15),'L-BFGS retraction-chain derivative qualification failed')
    def callback(x):
     counter[0]+=1;last_x[0]=x.copy();field=x.reshape(shape);field=field/np.linalg.norm(field,axis=-1,keepdims=True);field[mask]=[0.,0.,1.];last[0]=field.copy()
     if counter[0]%5==0:observe(field,counter[0])
    res=minimize(fg,n.ravel().copy(),method='L-BFGS-B',jac=True,callback=callback,options={'maxiter':50,'maxfun':200,'maxcor':5,'maxls':25,'ftol':0.,'gtol':1e-12});solver_message=str(res.message)
  except GateStop as ex:solver_message=str(ex)
  if history[-1]['iteration']!=counter[0]:
   try:observe(last[0],counter[0])
   except GateStop:pass
  
  if method=='CG-control':checkpoint(folder/'optimizer-final.npz',s,engine,{**identity(),'method':method,'backend':engine.kind})
  final=history[-1];status[0]=classify(final);need(final['energy']<=start_energy+1e-10,'Optimizer ended with higher energy');np.savez_compressed(folder/'final.npz',field=last[0],optimizer_coordinates=last_x[0]);item={'method':method,'accepted_steps':counter[0],'function_evaluations':calls[0] if method=='LBFGS-trial' else None,'solver_message':solver_message,'status':status[0],'metrics':final,'history':history,'field_sha256':sha(folder/'final.npz')};results.append(item);save(folder/'result.json',item)
 verify_sources();decision='ready_for_refinement_and_motion_admission_checks' if results[1]['status']=='strict_static_survivor_pending_mesh_confirmation' else 'not_ready_within_final_declared_audit_park_unchanged_route'
 result={'recorded_at':stamp(),'status':'comparison_complete_pending_review','identity':identity(),'audit':receipt,'backend':backend,'results':results,'decision':decision,'Q2_production_steps':0,'Q8_maximum_production_steps':100,'motion_execution':False,'not_a_physical_Q_rejection':True};save(out/'COMPARISON.json',result);report(result);log('Final bounded comparison finished',decision=decision,output=str(out))

def report(data):
 import html
 shutil.copytree(ROOT,out/'handover',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 text='<!doctype html><html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Final numerical decision audit</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:30px auto;padding:15px}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style><h1>Final numerical decision audit</h1><p>Original gates retained. A passing static test queues later refinement/admission; no physical electron result or motion is certified. Q2 is read-only. CPU reference and retained full-field results are explicit below.</p><pre>'+html.escape(__import__('json').dumps(data,indent=2))+'</pre></html>';(out/'REPORT.html').write_text(text)
 files=[f for f in out.rglob('*') if f.is_file() and f.suffix not in ['.npz','.tmp'] and f!=out/'SHA256SUMS' and f.name not in ['evidence.zip','worker.lock','status.json','heartbeat.json','runner.log']];save(out/'field-manifest.json',{'recorded_at':stamp(),'files':[{'path':f.relative_to(out).as_posix(),'sha256':sha(f)} for f in out.rglob('*.npz')]});files.append(out/'field-manifest.json') if out/'field-manifest.json' not in files else None
 (out/'SHA256SUMS').write_text(''.join(sha(f)+'  '+f.relative_to(out).as_posix()+'\n' for f in sorted(files)))
 with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(files)+[out/'SHA256SUMS']:z.write(f,f.relative_to(out))
 save(out/'status.json',{'recorded_at':stamp(),'status':data['status'],'output':str(out),'evidence':str(out/'evidence.zip'),'report':str(out/'REPORT.html')})
stop=threading.Event()
def pulse():
 while not stop.wait(15):save(out/'heartbeat.json',{'recorded_at':stamp(),'pid':os.getpid()})
save(out/'heartbeat.json',{'recorded_at':stamp(),'pid':os.getpid()});threading.Thread(target=pulse,daemon=True).start()
try:
 verify_package();guard()
 if a.mode=='audit':run_audit()
 else:compare()
except BaseException as ex:save(out/'status.json',{'recorded_at':stamp(),'status':'failed','error':str(ex)});traceback.print_exc();raise
finally:stop.set()

import argparse,os,subprocess,sys,secrets,zipfile,json
from pathlib import Path
from datetime import datetime,timezone
from support import *
p=argparse.ArgumentParser(description='Local retained-field audit and final bounded comparison; no GitHub interaction');p.add_argument('mode',choices=['verify','audit','compare','status']);p.add_argument('--repo',type=Path,default=Path.home()/'ElectronFieldTopology-campaign2');p.add_argument('--q2-run',type=Path,default=Path.home()/'ElectronFieldTopology-repository-admin/artifacts/s5-b/010-intermediate-q-survey/20261109t134425z-89d28344');p.add_argument('--q8-run',type=Path);p.add_argument('--output',type=Path);p.add_argument('--backend',choices=['cpu','auto','cuda'],default='cpu');a=p.parse_args()
def main():
 pkg=verify_package()
 if a.mode=='verify':log('Decision audit package verified',production_started=False);return
 repo=a.repo.resolve();need((repo/'pyproject.toml').is_file(),'Prepared source checkout missing; supply --repo');base=repo/'artifacts/final-decision-audit';base.mkdir(parents=True,exist_ok=True);pointer=base/'CURRENT-20261116.json'
 if a.output:out=a.output.resolve()
 elif pointer.exists():out=Path(load(pointer)['output'])
 elif a.mode=='audit':out=base/(datetime.now(timezone.utc).strftime('%Y%m%dt%H%M%Sz-')+secrets.token_hex(4))
 else:raise RuntimeError('Run audit first')
 if a.mode=='status':
  status=load(out/'status.json') if (out/'status.json').exists() else {};heartbeat=load(out/'heartbeat.json') if (out/'heartbeat.json').exists() else {};pid=heartbeat.get('pid');alive=False
  if pid:
   try:cmdline=(Path('/proc')/str(pid)/'cmdline').read_bytes().replace(b'\0',b' ').decode();alive=str(ROOT/'local_audit.py') in cmdline and str(out) in cmdline
   except (FileNotFoundError,PermissionError):pass
  log('Audit status',runner_alive=alive,output=str(out),status=status,heartbeat=heartbeat,runner_log=str(out/'runner.log'));return
 q8=a.q8_run
 if q8 is None:
  expected=load(ROOT/'ANCHORS.json')['Q8']['archive_sha256'];found=[p.parent.resolve() for p in repo.glob('artifacts/targeted-q-campaign2/*/evidence.zip') if sha(p)==expected];need(len(found)==1,'Supply --q8-run pointing to the completed campaign2 run');q8=found[0]
 q8=q8.resolve();q2=a.q2_run.resolve();config={'package_sha256':pkg,'repo':str(repo),'q2_run':str(q2),'q8_run':str(q8)};out.mkdir(parents=True,exist_ok=True)
 if (out/'configuration.json').exists():need(load(out/'configuration.json')==config,'Audit configuration changed; use a fresh --output')
 else:need(not any(out.iterdir()),'Output directory is not empty');save(out/'configuration.json',config)
 save(pointer,{'recorded_at':stamp(),'output':str(out),'package_sha256':pkg});env=os.environ.copy()
 for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:env[key]='4'
 argv=['uv','run','--frozen','--python','3.12.14']
 if a.mode=='compare' and a.backend!='cpu':argv+=['--extra','gpu']
 argv+=['python',str(ROOT/'local_audit.py'),a.mode,'--repo',str(repo),'--q2-run',str(q2),'--q8-run',str(q8),'--output',str(out),'--backend',a.backend]
 if a.mode=='audit':
  result=subprocess.run(argv,cwd=repo,env=env);need(result.returncode==0,'Retained-field audit stopped; inspect status/output');log('Audit receipt available',output=str(out));return
 need((out/'AUDIT.json').exists(),'Run audit first')
 if not load(out/'AUDIT.json')['comparison_allowed']:log('Comparison blocked by audit outcome; provide evidence.zip for review',output=str(out));return
 if (out/'COMPARISON.json').exists():log('Comparison already complete',output=str(out));return
 need(not (out/'CG-control').exists(),'A partial comparison exists; preserve it for review rather than overwriting it')
 with (out/'runner.log').open('a') as f:child=subprocess.Popen(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 save(out/'launch.json',{'recorded_at':stamp(),'pid':child.pid,'argv':argv});save(out/'status.json',{'recorded_at':stamp(),'status':'comparison_starting','launcher_pid':child.pid});log('Final bounded comparison launched',pid=child.pid,output=str(out),log=str(out/'runner.log'))
try:main()
except Exception as e:log('Decision handover stopped',error=str(e));sys.exit(1)

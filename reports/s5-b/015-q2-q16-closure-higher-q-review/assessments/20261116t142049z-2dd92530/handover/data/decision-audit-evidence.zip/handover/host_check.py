from pathlib import Path
import importlib.util,sys,types,json,hashlib,time
from dataclasses import dataclass
import numpy as np
from scipy.optimize import minimize
root=Path(__file__).resolve().parent;root.mkdir(parents=True,exist_ok=True)
# Execute the exact saved array port and seed code with a declared positive normalization.
package=types.ModuleType('verified_array');package.__path__=[];sys.modules['verified_array']=package
sk=types.ModuleType('verified_array.skyrme');sk.K=1.;sk.NORTH=np.array([0.,0.,1.]);sys.modules[sk.__name__]=sk
src=root/'source_arrays/sf_time_gpu.py';seedfile=root/'source_arrays/sf_candidate_seeds.py'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
port=module('verified_array.sf_time_gpu',src).ArrayTime(np);seeds=module('verified_array.sf_candidate_seeds',seedfile)
@dataclass(frozen=True)
class Grid:
 shape:tuple
 lengths:tuple
 boundary:str='fixed'
 @property
 def spacing(self):return tuple(l/(n-1 if self.boundary=='fixed' else n) for l,n in zip(self.lengths,self.shape))
 def fixed_mask(self):
  m=np.zeros(self.shape,bool)
  if self.boundary=='fixed':
   for axis in range(3):
    sl=[slice(None)]*3;sl[axis]=slice(None,2);m[tuple(sl)]=True;sl[axis]=slice(-2,None);m[tuple(sl)]=True
  return m
 def points(self):return np.stack(np.meshgrid(*[-l/2+np.arange(n)*h for l,n,h in zip(self.lengths,self.shape,self.spacing)],indexing='ij'),axis=-1)
def cone(n):
 shape=tuple(v-1 for v in n.shape[:3]);total=np.zeros(shape+(3,));parts=[]
 for bits in np.ndindex(2,2,2):
  piece=n[tuple(slice(b,b+v) for b,v in zip(bits,shape))];parts.append(piece);total+=piece
 size=np.linalg.norm(total,axis=-1,keepdims=True)
 if size.min()<1e-12:return -1.
 centre=total/size;return min(float(np.min(np.sum(v*centre,axis=-1))) for v in parts)

def projector(n,x):return x-n*np.sum(n*x,axis=-1,keepdims=True)
def algebra(n,g):
 n=port.retract(n,np.zeros_like(n),g)[0];energy,gradient=port.static_value_gradient(n,g);_,acc=port.acceleration(n,np.zeros_like(n),g);d=port.gradients(n-port.north,g);mass=(1+np.sum(d*d,axis=(-2,-1)))[...,None,None]*np.eye(3)-np.einsum('...ia,...ib->...ab',d,d)
 residual=projector(n,np.einsum('...ab,...b->...a',mass,acc))+projector(n,gradient)/(2*np.prod(g.spacing));residual[g.fixed_mask()]=0
 scale=max(float(np.max(abs(gradient)))/(2*np.prod(g.spacing)),1e-30)
 return {'energy_K1':energy,'scaled_mass_gradient_identity_max_error':float(np.max(abs(residual))),'relative_identity_error':float(np.max(abs(residual)))/scale,'tangency_max':float(np.max(abs(np.sum(n*acc,axis=-1)))),'fixed_acceleration_max':float(np.max(abs(acc[g.fixed_mask()]))) if g.boundary=='fixed' else 0.},gradient,acc
rng=np.random.default_rng(7143);rows=[]
for kind,nodes,boundary in [('smooth',17,'fixed'),('smooth',16,'periodic'),('fresh-axial-Q2',25,'fixed'),('fresh-trefoil-Q8',25,'fixed')]:
 g=Grid((nodes,)*3,(12.,)*3,boundary)
 if kind=='smooth':
  x=g.points();u=.1*np.sin(.7*x[...,0]+.3*x[...,1]);v=.12*np.cos(.4*x[...,1]-.2*x[...,2]);n=np.stack([u,v,np.sqrt(1-u*u-v*v)],axis=-1);n[g.fixed_mask()]=port.north
 else:
  q=2 if 'Q2' in kind else 8;seed={'family':'axial' if q==2 else 'trefoil32','q':q,'alpha':2 if q==2 else 1,'beta':1 if q==2 else 2,'scale':1.7,'cutoff':4.,'bend':0.,'amplitude':1.,'perturbation':.005};n=seeds.sampled(g,seed)
 result,gradient,acc=algebra(n,g);fd=[]
 for trial in range(3):
  direction=projector(n,rng.normal(size=n.shape));direction[g.fixed_mask()]=0;direction/=np.linalg.norm(direction);analytic=float(np.sum(gradient*direction));points=[]
  for eps in [.03,.01,.003,.001,.0003,.0001]:
   plus=port.retract(n+eps*direction,np.zeros_like(n),g)[0];minus=port.retract(n-eps*direction,np.zeros_like(n),g)[0];numeric=(port.static_value_gradient(plus,g)[0]-port.static_value_gradient(minus,g)[0])/(2*eps);points.append({'epsilon':eps,'absolute_error':abs(numeric-analytic),'relative_error':abs(numeric-analytic)/max(abs(analytic),1e-30)})
  best=min(points,key=lambda x:x['absolute_error']);assert best['relative_error']<2e-6 or best['absolute_error']<1e-8;fd.append({'analytic_directional_derivative':analytic,'best':best,'sweep':points})
 assert result['relative_identity_error']<1e-11 and result['tangency_max']<1e-11 and result['fixed_acceleration_max']==0
 # Independent L-BFGS retraction chain rule is also checked by finite differences.
 x=n.copy();norm=np.linalg.norm(x,axis=-1,keepdims=True);chain=projector(n,gradient)/norm;chain[g.fixed_mask()]=0;direction=rng.normal(size=x.shape);direction[g.fixed_mask()]=0;direction/=np.linalg.norm(direction)
 eps=.001;fun=lambda y:port.static_value_gradient(port.retract(y,np.zeros_like(y),g)[0],g)[0];fdchain=(fun(x+eps*direction)-fun(x-eps*direction))/(2*eps);analytic=float(np.sum(chain*direction));assert abs(fdchain-analytic)<1e-6*max(1,abs(analytic))
 # Bounded algorithm smoke on the fresh states only; not retained candidate proof.
 opt=None
 if 'fresh' in kind:
  shape=n.shape;fixed=g.fixed_mask();history=[]
  def fg(flat):
   x=flat.reshape(shape);size=np.linalg.norm(x,axis=-1,keepdims=True);nn=x/size;nn[fixed]=port.north;e,grad=port.static_value_gradient(nn,g);gg=projector(nn,grad)/size;gg[fixed]=0;return e,gg.ravel()
  initial=fg(n.ravel())[0];res=minimize(fg,n.ravel(),method='L-BFGS-B',jac=True,options={'maxiter':20,'maxfun':100,'maxcor':5,'ftol':0.,'gtol':1e-12},callback=lambda x:history.append(fg(x)[0]));assert res.fun<initial and all(b<=a+1e-8 for a,b in zip(history,history[1:]));opt={'accepted_iterations':int(res.nit),'evaluations':int(res.nfev),'initial_energy_K1':initial,'final_energy_K1':float(res.fun),'solver_message':str(res.message),'initial_corner_cone':cone(n),'final_corner_cone':cone(port.retract(res.x.reshape(shape),np.zeros_like(n),g)[0]),'representation_audited':False,'candidate_result':False,'scope':'Fresh coarse initialized map; not the retained reference or failed endpoint'}
 rows.append({'kind':kind,'nodes':nodes,'boundary':boundary,**result,'finite_variations':fd,'lbfgs_smoke':opt});print(kind,result['relative_identity_error'],max(x['best']['relative_error'] for x in fd),opt,flush=True)
result={'status':'local_array_operator_audit_passed','normalization':'K=1 positive scalar test normalization; consistency identities and relative derivative tests are independent of the physical normalization constant','source_sha256':{'sf_time_gpu.py':hashlib.sha256(src.read_bytes()).hexdigest(),'sf_candidate_seeds.py':hashlib.sha256(seedfile.read_bytes()).hexdigest()},'cases':rows,'limits':['Exact source array port executed on NumPy; no CUDA execution and no direct original CPU-module replay on this host','Grid test harness uses the stated periodic/fixed geometry and two held layers; not the missing repository Grid source','Fresh Q-labeled initialized maps do not replace retained Q2/Q8 field tests and do not certify numerical topological charge','No gate relaxation, production candidate acceptance or physical conclusion']}
print(json.dumps(result,indent=2))

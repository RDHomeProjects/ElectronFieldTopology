# Combined endpoint audit and admitted temporal convergence

Prepared UTC 2026-11-06 / Australia/Melbourne 2026-11-07. Exact creation and validation timestamps are in PACKAGE.json and VALIDATION.json. S5-B-006, based on merged PR60/main4e4ff50657fa312a4e764a0ec53a42e422a183da.

One unattended workflow: replay the Q1 endpoint/controller audit, run independent analytical time/boundary controls, readmit larger boxes, then run Q1/x and Q2/z at beta0.3 to T1 with dt0.01/0.005/0.0025. CPU float64; original action/RK4 kernels and all historical evidence remain unchanged.

## Domain selection and tails

|Model|First box|Fallback|Rest spacing|
|---|---|---|---:|
|Q1/x|L24.32/n153|L26.56/n167|0.16|
|Q2/z|L20.16/n127|L22.08/n139|0.16|

Original two-unit shell limit remains0.1%. Admission requires initial and projected-coasting T1 tails<=0.075%, plus a width3 guard<=0.1%. During evolution tail observations occur every0.05 physical time. Above0.09%, the accepted state is saved, the attempt remains evidence, and the full three-dt family restarts on the next declared domain. A sample that crosses0.1% retains its failure. No grid mixing, weaker threshold, compression or taper. Fallback exhaustion is a completed blocked-admission result requiring review. No zero-failure guarantee or assertion about unsampled times is made. All other original scientific gates remain recorded even when false.

Full state snapshots at T=.25/.5/.75/1 support matched-region temporal comparisons. This does not establish physical-mesh/domain convergence or electron, charge or quantum-spin acceptance. Renderer exports are disabled for this run; scientific precision is unaffected. See the installed docs/models/SF-admitted-temporal.md for the full registered contract and source equations.

## Install and start

Use the consolidated administrative checkout. Installation backs up Git and applies a staged additive patch; it never resets, deletes, pushes or starts computation. It verifies exact main before first install and refuses unrelated tracked edits. Repeating an exact install is safe. Untracked conflicts are retained and cause Git application to stop. Keep the old runs and this download until archived.

```bash
(
set -euo pipefail
unzip -n "$HOME/Downloads/ElectronFieldTopology-audit-convergence-20261107.zip" -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-audit-convergence-20261107"
bash "$package/INSTALL.sh"
cd "$HOME/ElectronFieldTopology-repository-admin"
uv sync --frozen --all-groups --python 3.12.14
bash "$package/RUN.sh" test
bash "$package/RUN.sh" commit
bash "$package/RUN.sh" start
)
```

Use the mains-powered workstation with suspend disabled during computation. Rough first-domain estimate16–24 hours, potentially longer with rest preparation/load or larger-domain retries. No overall time cap. At least16GiB free is enforced;32GiB or more recommended for fallback and archive download verification. The source fields are reused locally or restored from authenticated GitHub Release archives automatically. Source restore may download roughly0.9GB compressed and retains restored copies. Nothing assumes an old standalone checkout still exists. To use another checkout, add `--repo /absolute/path` consistently. An optional `--source /absolute/path/map.json` map contains q1 and q2 retained run-root paths; checkpoints are still authenticated.

## Status and recovery

```bash
package="$HOME/Downloads/ElectronFieldTopology-audit-convergence-20261107"
bash "$package/RUN.sh" status
```

Finished means runner_alive=false AND status=complete_pending_review (two selected model families) or complete_admission_blocked_pending_review (declared work finished with at least one model blocked), with matching exit.json. Inactivity alone is not completion. Status prints output, summary, evidence, heartbeat, current rest/trajectory and error details. Results carry UTC/Melbourne timestamps; all snapshots/checkpoints remain full-resolution float64.

```bash
bash "$package/RUN.sh" stop
# Wait until status reports the worker stopped, then:
bash "$package/RUN.sh" resume
```

Resume checks inputs/code/config and saved states. It refuses to resume a completed run. `start` after completion intentionally creates a new campaign; use status or publish for the existing completed one. Do not move the checkout or run paths during computation/resume. After archiving, catalog-based restoration supports explicit analysis roots; historical absolute provenance paths are not silently rewritten.

## Publish, archive, then merge

Run only when complete. These commands are explicit GitHub mutations from your workstation. They record the compact results and pending-review status, archive every new full field/snapshot and this runnable handover, independently download/hash verify, register the catalog, then wait for hosted checks and merge the exact current head. No automatic scientific acceptance or cleanup. Do not run a new `start` between these commands. A publish followed by archive updates the same PR.

```bash
(
set -euo pipefail
package="$HOME/Downloads/ElectronFieldTopology-audit-convergence-20261107"
bash "$package/PUBLISH.sh"
bash "$package/ARCHIVE.sh"
bash "$package/MERGE.sh"
)
```

If interrupted during archive, rerun ARCHIVE.sh: the unchanged engine resumes its own verified session. The wrapper retries only transient read-side HTTP5xx and uses public download fallback only for authenticated asset hashes. No upload, checksum error or scientific failure is bypassed. Existing data are never deleted. Send the completed evidence.zip and SUMMARY.md for assessment; the registered Release archive retains full fields for independent replay.

Validation distinguishes real source probes/analytical controls from small-grid software fixtures and fully mocked GitHub publication tests. No new production Q1/Q2 trajectory was performed while building this handover. AI-assisted implementation and documentation; no external peer review implied.

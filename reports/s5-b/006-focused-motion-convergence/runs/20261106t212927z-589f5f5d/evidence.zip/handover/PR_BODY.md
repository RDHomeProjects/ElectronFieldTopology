## Combined endpoint audit and boundary-admitted temporal refinement

Continue S5-B-006 after assessed PR60. Separate strict endpoint residuals, stable regular windows and the historical endpoint certificate without editing S5-B-009's native labels. Run one declared Q1/x and Q2/z beta0.3, T1 three-dt matrix after new rest/boundary admission.

Use h0.16 with Q1 L24.32/n153 (fallback26.56/n167), Q2 L20.16/n127 (fallback22.08/n139). Original0.1% width2 tail limit remains unchanged. Initial0.075%, expanded guard and runtime0.09% reserve trigger retained rejection and complete-family larger-box retry. All original negative shape/speed/momentum/tail gates remain visible. This is temporal refinement on a finite physical grid, not mesh/domain isolation acceptance.

Full-state matched-time snapshots, timestamps, source/config/checkpoint digests and exact source archives are retained. Compact result and registered full-field Release archive are required before merge. No scientific acceptance or local cleanup follows from publication. The roadmap and generated plan/navigation reflect the new preparation/recorded increment while retaining the last assessed study and all historical evidence.

Validation: independent closed-form fourth-order temporal control, unchanged-kernel/observer endpoint equivalence, accepted-state safety stops with original failure flags, stop/resume, full three-dt workflow and whole-family fallback controls, retained-source projection probe, frozen evidence/links and local handover rehearsal. GitHub mutations were mocked during preparation. See the timestamped preparation validation for exact results, dependencies and limitations.

Requirements NUM-001/002/003, BND-001, REL-002, REP-001/002, SCI-003/004. Neutral D4/RK4, metric +---, c=1, dimensionless units, CPU float64. Existing equation/source maps unchanged; no quantum spin, charge, electron or isolated-motion claim. AI-assisted implementation and records.

# Paired Q1 tail-settling overnight handover — S5-B-009

Prepared: UTC 2026-11-05T20:58:49.887092+00:00; Australia/Melbourne 2026-11-06T07:58:49.887092+11:00.

This package prepares the next task after merged PR59, pinned main commit `5bf6ae24732674d5265af046bd4701ce68891123`. PACKAGE.json records creation time in UTC and Australia/Melbourne.

Run Q1 at L20.16/n127 and L22.08/n139, both h=.16, independently from the same authenticated retained Q1/L20.16 field. Keep original Hamiltonian, coefficients, boundaries and 0.1% shell criterion. This is stationary settling and domain correction, not motion. Q2 is not rerun.

Up to 1200 genuine optimizer iterations per arm, 200-iteration batches, checkpoints every 25 iterations, full observation fields every 100. Tighter force targets and three separated tail/core settling intervals determine convergence. The controller can stop earlier on convergence, numerical stall or topology failure. Budget exhaustion is explicitly unresolved. There is no wall-time cutoff or idle padding. Budget-based estimate: roughly 10–14 hours if consumed, with uncertainty from tight line searches; it can finish substantially earlier.

## Install, validate, commit, start

```bash
(
set -euo pipefail
unzip -n "$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106.zip" -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106"
bash "$package/INSTALL.sh"
bash "$package/RUN.sh" test
bash "$package/RUN.sh" commit
bash "$package/RUN.sh" start
bash "$package/RUN.sh" status
)
```

Uses the consolidated `~/ElectronFieldTopology-repository-admin` checkout, branch `work/s5-b-009-q1-tail-settling`. Each command accepts `--repo /absolute/checkout` if needed. Install makes a verified complete-history Git bundle; it does not reset, remove artifacts or push. Repeated exact installation preserves staging/commits. Changed files or an advanced main stop with an explicit diagnostic.

Default source: the prior S5-B-008 artifact in this checkout. If absent, start restores the authenticated 284 MiB Release root through the existing download-and-verification tool. It needs your existing `gh` access. A wrong existing source is rejected, never overwritten. An explicit restored run root may be supplied with `RUN.sh start --source /absolute/run-root`. Only the Q1/L20.16 endpoint is used; no older multi-gigabyte source campaign is required.

Keep the workstation on AC power and prevent automatic suspend for the overnight calculation. CPU float64 is deliberate: the existing GPU static solver has a different discrete functional. The renderer does not run. At least 4 GiB free workspace is required for retained fields and archive staging.

## Monitor, stop and resume

```bash
bash "$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106/RUN.sh" status
bash "$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106/RUN.sh" stop
# Wait until status reports runner_alive=false before resuming:
bash "$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106/RUN.sh" resume
```

Status reports run path, heartbeat, optimizer history, summary and evidence. Completion requires both arms, a matching final exit record and status `complete_pending_review` or `complete_with_unresolved_pending_review`; an inactive runner alone is insufficient. Check SUMMARY.md to distinguish settled, budget-exhausted and unresolved numerical outcomes. All are retained for analysis. Do not resume a completed run as if it had more work; extensions require a new recorded configuration/decision.

Restart validates immutable inputs/code/config and NPZ identity/constraints. Conjugate-gradient memory is reset, so it is a valid restart rather than a bit-exact continuation. Initial/latest fields and every observation remain local until the full run is uploaded and download-verified. Nothing deletes local originals.

## Publish every result and full field

Once status confirms completion:

```bash
(
set -euo pipefail
package="$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106"
bash "$package/PUBLISH.sh"
bash "$package/ARCHIVE.sh"
)
```

PUBLISH commits compact records, current register/plan/status updates and opens/updates one PR. It checks all initial/latest and observation checkpoint hashes. ARCHIVE uploads the complete new run, logs and runnable handover to a GitHub Release, downloads/verifies every archived payload, registers the catalog in Git and updates the same PR. Existing released input is not duplicated unnecessarily. REST metadata avoids the older GitHub CLI Projects Classic failure.

Provide the resulting PR URL and the new evidence.zip for scientific assessment. After that review, merge the recorded results with:

```bash
bash "$HOME/Downloads/ElectronFieldTopology-Q1-tail-overnight-20261106/MERGE.sh"
```

Merge checks the verified archive receipt, local/remote head equality and hosted checks, then uses `--match-head-commit`. Publication/merge is not scientific acceptance. No automatic downstream motion, Q catalogue, charge or spin run is launched.

## Preservation and scope

Canonical study `reports/s5-b/009-q1-tail-settling/`; immutable preparation/run records and one generated project register. Existing report paths, recorded bytes and scientific kernels are preserved. The new controller reuses the original Hamiltonian/gradient and CG step with changed observation/stopping rules only. See the model contract and preparation validation in the patch. All run outputs, analyses, logs and figures carry UTC/Melbourne timestamps. No production result is included in this preparation handover.

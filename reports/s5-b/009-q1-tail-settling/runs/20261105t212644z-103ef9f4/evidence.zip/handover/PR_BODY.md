Prepared: UTC 2026-11-05T20:58:49.887092+00:00; Australia/Melbourne 2026-11-06T07:58:49.887092+11:00.

Prepare and record the paired Q1 stationary settling follow-up to S5-B-008. The retained L20.16 endpoint is copied unchanged into its control arm and exactly north-extended into L22.08 at h=.16. This separates deeper optimizer settling from the domain change while retaining the original Hamiltonian and 0.1% shell criterion.

S5-B-009 allocates up to 1200 actual optimizer iterations per arm with strict force targets, three separated tail/core observation intervals, checkpoints, process-identity tracking and resumability. Numerical stalls, tail failures and budget exhaustion remain explicit evidence. It adds no physical-time evolution or acceptance of isolated motion, charge, spin or an electron model.

The canonical register, model contract, generated status/plan and immutable preparation record are updated together. Requirement IDs: NUM-001/002/003, BND-001, REP-001/002 and SCI-003/004. Validation includes small optimizer equivalence, settling/budget/restart/integrity controls and repository preservation checks; see the timestamped preparation record for exact evidence and limitations. Existing scientific kernels and prior published records remain unchanged.

Compact results and a separately registered download-verified Release archive of all new fields, observation checkpoints, logs and runnable handover are required before merge. The complete native run remains subject to scientific assessment.

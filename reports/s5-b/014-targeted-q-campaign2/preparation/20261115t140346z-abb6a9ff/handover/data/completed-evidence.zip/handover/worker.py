import argparse,os,sys,time,zipfile,shutil,json,threading,signal,traceback,fcntl,gc
from pathlib import Path
from support import *
p=argparse.ArgumentParser();p.add_argument('mode',choices=['preflight','run']);p.add_argument('--repo',type=Path,required=True);p.add_argument('--source-run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--backend',choices=['auto','cpu','cuda'],required=True);a=p.parse_args()
repo=a.repo.resolve();source=a.source_run.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
lock=(out/'worker.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,str(repo/'src'))
import numpy as np
from electron_field_topology.sf_time import Grid
from electron_field_topology.sf_readmission import static_value_gradient,stationarity
from electron_field_topology.sf_temporal_metrics import tail_band
from electron_field_topology.rapid_q_screen.engine import Engine,checkpoint,restore
from electron_field_topology.rapid_q_screen.policy import representation,stationary,classify
from analysis import spatial_summary,curve_fits
PLAN=load(ROOT/'PLAN.json');GATES=load(ROOT/'GATES.json')
with zipfile.ZipFile(ROOT/'data/parent-evidence.zip') as z:
 parent=json.loads(z.read('record.json'));field_manifest=json.loads(z.read('field-manifest.json'))['files'];imports={j['job']['id']:json.loads(z.read('jobs/'+j['job']['id']+'/import.json')) for j in parent['jobs']}
rows={j['job']['id']:j for j in parent['jobs']};fieldmap={f['path']:f for f in field_manifest}

def metrics(n,g):return {**stationarity(n,g),'tail_fraction':tail_band(n,np.zeros_like(n),g,GATES['shell_width'])['fraction']}
def guard():
 mem={l.split(':')[0]:l.split(':')[1] for l in Path('/proc/meminfo').read_text().splitlines()};available=int(mem['MemAvailable'].split()[0])/1024**2
 need(available>=PLAN['memory_reserve_gib'],'Host memory reserve below 4 GiB')
 need(shutil.disk_usage(out).free>=PLAN['disk_reserve_gib']*1024**3,'Free disk reserve below 12 GiB; all fields retained')
def safe(path):
 f=(source/path).resolve();need(f.is_relative_to(source) and f.is_file(),'Missing or unsafe source field: '+str(f));return f
def source_verify(full):
 need(source.name==PLAN['parent_run'] and sha(source/'evidence.zip')==PLAN['parent_sha256'],'Wrong completed parent run')
 for name,h in load(ROOT/'SOURCE.json').items():need((repo/name).is_file() and sha(repo/name)==h,'Source/lock changed: '+name)
 for name in ['record.json','field-manifest.json']:
  with zipfile.ZipFile(ROOT/'data/parent-evidence.zip') as z:need(sha(source/name)==__import__('hashlib').sha256(z.read(name)).hexdigest(),'Parent metadata changed: '+name)
 if full:
  for f in field_manifest:
   path=safe(f['path']);need(sha(path)==f['sha256'],'Parent field changed: '+f['path'])
   with zipfile.ZipFile(path) as z:need(z.testzip() is None,'NPZ CRC failed: '+f['path'])
  log('All retained parent fields verified',count=len(field_manifest))

def read_state(path,expected,iteration,nodes):
 need(sha(path)==expected,'Selected source checkpoint hash differs')
 with np.load(path,allow_pickle=False) as z:
  need(int(z['iteration'])==iteration,'Selected checkpoint iteration differs')
  state={k:float(z[k]) if k=='alpha' else int(z[k]) for k in ['alpha','iteration','next_observe','observe_spacing']}
  for k in ['n','old_g','old_z','direction']:
   arr=z[k];need(arr.dtype==np.float64 and np.isfinite(arr).all(),'Invalid source array: '+k)
   need(arr.size==0 or arr.shape==(nodes,)*3+(3,),'Checkpoint shape differs')
   state[k]=arr.copy() if arr.size else None
  original_backend=str(z['backend']);original_identity=str(z['identity_sha256'])
 need(state['n'] is not None,'Missing source field')
 return state,{'backend':original_backend,'identity_sha256':original_identity,'sha256':expected,'path':str(path)}
def endpoint(key,start=False):
 row=rows[key];rel='jobs/'+key+'/followup-start.npz' if start else row['checkpoint'];it=row['job']['start_iteration'] if start else row['iteration']
 state,meta=read_state(safe(rel),fieldmap[rel]['sha256'],it,row['nodes'])
 if not start:need(meta['identity_sha256']==row['branch_identity_sha256'],'Source branch identity differs')
 return state,meta

def adapt_state(s,e):return {k:(e.xp.asarray(v).copy() if k in ['n','old_g','old_z','direction'] and v is not None else v) for k,v in s.items()}
def clone_state(s,e):return adapt_state(s,e)
def cpu_replay(key,s,g,expected):
 m=metrics(s['n'],g)
 for k,v in expected.items():
  if isinstance(v,(float,int)) and k in m:need(np.isclose(m[k],v,rtol=1e-9,atol=1e-12),'CPU metric replay mismatch: '+key+' '+k)
 return m

def qualify(s,g,label):
 cpu=Engine('cpu');cpu.audit(s['n'],g);times=[]
 for i in range(3):
  disposable=adapt_state(s,cpu);t=time.perf_counter();accepted,info=cpu.step(disposable,g);cpu.sync();times.append(time.perf_counter()-t)
  if i==0:reference=cpu.host(disposable['n']);ref_accepted=accepted
  del disposable
 result={'recorded_at':stamp(),'label':label,'nodes':g.shape[0],'cpu_median_step_seconds':float(np.median(times[1:])),'disposable_cpu_steps':3,'selected_backend':'cpu','production_steps':0,'CPU_GPU_parity':None}
 if a.backend=='cpu':return result
 try:
  gpu=Engine('cuda');gs=adapt_state(s,gpu);gpu.audit(gs['n'],g,GATES['qualification_rtol'],GATES['qualification_atol']);gt=[]
  for i in range(3):
   disposable=adapt_state(s,gpu);gpu.sync();t=time.perf_counter();accepted,info=gpu.step(disposable,g);gpu.sync();gt.append(time.perf_counter()-t)
   need(accepted==ref_accepted,'CPU/GPU acceptance disagreement');actual=gpu.host(disposable['n']);need(np.allclose(reference,actual,rtol=2e-9,atol=2e-10),'CPU/GPU disposable step field disagreement')
   del disposable
  result.update(cuda_median_step_seconds=float(np.median(gt[1:])),cuda_identity=gpu.port.identity(),CPU_GPU_parity='passed',maximum_step_field_difference=float(np.max(abs(reference-actual))))
  result['speedup']=result['cpu_median_step_seconds']/max(result['cuda_median_step_seconds'],1e-12)
  if a.backend=='cuda' or result['speedup']>=GATES['gpu_speedup_required']:result['selected_backend']='cuda'
  del gpu,gs
 except Exception as ex:
  if a.backend=='cuda':raise
  result['cuda_unavailable_or_rejected']=str(ex);result['selected_backend']='cpu';log('CUDA not selected; explicit CPU qualification retained',label=label,reason=str(ex))
 gc.collect();return result

def engine_for(label,receipt):
 q=receipt['backends'][label];e=Engine(q['selected_backend'])
 if e.kind=='cuda':need(e.port.identity()==q['cuda_identity'],'CUDA runtime/device changed since qualification')
 return e

def diagnose():
 result=[]
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 for key in ['q4-axial22','q6-axial6-1']:
  seen=set();candidates=[f for f in field_manifest if f['path'].startswith('jobs/'+key+'/') and (f['path'].endswith('followup-start.npz') or '/stage-' in f['path'])]
  for f in candidates:
   if f['sha256'] in seen:continue
   seen.add(f['sha256']);guard();path=safe(f['path']);nodes=rows[key]['nodes'];g=Grid((nodes,)*3,(23.04,)*3,'fixed')
   with np.load(path,allow_pickle=False) as z:it=int(z['iteration'])
   s,meta=read_state(path,f['sha256'],it,nodes);m=metrics(s['n'],g);energy,raw=static_value_gradient(s['n'],g)
   d,magnitude=spatial_summary(s['n'],raw,g.spacing,g.fixed_mask(),s)
   del raw
   d.update(seed=key,iteration=it,metrics=m,source=meta,relaxation_steps_allocated=0)
   plot=out/'diagnostics'/f'{key}-{it:04d}.png';plot.parent.mkdir(exist_ok=True)
   fig,axes=plt.subplots(1,3,figsize=(13,4),layout='constrained')
   for axis,ax in enumerate(axes):
    projection=np.max(magnitude,axis=axis);im=ax.imshow(np.log10(np.maximum(projection,1e-20)),origin='lower',extent=[-11.52,11.52,-11.52,11.52],cmap='magma');ax.set_title('Max projection, axis '+str(axis));ax.set_xlabel('Model coordinate');fig.colorbar(im,ax=ax,label='log10 projected raw gradient')
   fig.suptitle(key+' retained iteration '+str(it));fig.savefig(plot,dpi=220);plt.close(fig);d['plot']=plot.relative_to(out).as_posix();result.append(d);save(out/'diagnostics.json',{'recorded_at':stamp(),'states':result,'q4_q6_added_steps':0});del s,magnitude;gc.collect()
 return result

def fine_q5():
 from electron_field_topology.sf_reconstruction import sample_cubic
 s,meta=endpoint('q5-trefoil32-1-1',True);old=Grid((97,)*3,(23.04,)*3,'fixed');g=Grid((121,)*3,(23.04,)*3,'fixed');n=sample_cubic(s['n'],old,g.points(),2)[0]
 before=float(np.max(abs(np.linalg.norm(n,axis=-1)-1)));boundary=float(np.max(abs(n[g.fixed_mask()]-[0,0,1])));size=np.linalg.norm(n,axis=-1,keepdims=True);need(np.isfinite(n).all() and size.min()>1e-12,'Invalid interpolated field');n=n/size;n[g.fixed_mask()]=[0.,0.,1.]
 state=Engine('cpu').state(n);state['iteration']=50
 return state,g,{'parent':meta,'interpolation':'existing cubic sampler, held_layers=2, normalized then fixed boundary','max_unit_error_before_final_normalization':before,'max_fixed_boundary_correction':boundary,'coarse_and_fine_restart_conjugacy':True,'common_parent_native_iteration':50}

def identity():return {'package_sha256':verify_package(),'repo':str(repo),'source_run':str(source),'backend_request':a.backend,'source_code_sha256':load(ROOT/'SOURCE.json'),'source_commit':__import__('subprocess').check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'python':sys.version,'numpy':np.__version__,'scipy':__import__('scipy').__version__,'threads':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']}}

def preflight():
 guard();source_verify(True);diag=diagnose();backends={};replays=[]
 for key in ['q8-trefoil32-1-2','q10-trefoil32-2-2','q5-trefoil32-1-1']:
  s,meta=endpoint(key,key.startswith('q5'));g=Grid((rows[key]['nodes'],)*3,(23.04,)*3,'fixed');expected=rows[key]['job']['metrics'] if key.startswith('q5') else rows[key]['metrics'];m=cpu_replay(key,s,g,expected)
  need(representation(m,rows[key]['q'],GATES),'Selected source lacks representation admission: '+key)
  if key.startswith('q5'):s=Engine('cpu').state(s['n']);s['iteration']=50
  replays.append({'seed':key,'source':meta,'replayed_metrics':m});backends[key]=qualify(s,g,key);save(out/'qualification-progress.json',{'recorded_at':stamp(),'backends':backends});del s;gc.collect()
 s,g,interp=fine_q5();m=metrics(s['n'],g);save(out/'q5-interpolation.json',{'recorded_at':stamp(),**interp,'metrics':m,'representation_pass':representation(m,5,GATES),'tail_pass':m['tail_fraction']<=GATES['initial_tail_limit']});backends['q5-fine']=qualify(s,g,'q5-fine');del s;gc.collect()
 receipt={'recorded_at':stamp(),'status':'local_preflight_passed','identity':identity(),'backends':backends,'endpoint_replays':replays,'diagnostic_states':len(diag),'scope':'Production has not started. Timed CPU/CUDA steps use disposable copies. Q4/Q6 inspected read-only; Q5 CPU/GPU checks occur after interpolation.'};save(out/'preflight.json',receipt);(out/'preflight.sha256').write_text(sha(out/'preflight.json')+'\n');log('Local diagnostics and backend qualification passed',backends={k:v['selected_backend'] for k,v in backends.items()});return receipt

def save_history(folder,h):
 save(folder/'history.json',h);(folder/'history.sha256').write_text(sha(folder/'history.json')+'\n')

def branch_job(key,label,maximum,base,receipt,fine=False):
 folder=out/'jobs'/label;folder.mkdir(parents=True,exist_ok=True);summary=folder/'summary.json'
 if summary.exists():
  need(sha(summary)==summary.with_suffix('.sha256').read_text().strip(),'Result summary seal changed');item=load(summary);need(sha(out/item['checkpoint'])==item['checkpoint_sha256'],'Completed result checkpoint changed');return item
 e=engine_for('q5-fine' if fine else key,receipt);seed=rows[key]['seed'];start=50 if key.startswith('q5') else rows[key]['iteration'];g=Grid(((121 if fine else rows[key]['nodes']),)*3,(23.04,)*3,'fixed');ident={**receipt['identity'],'seed':seed,'label':label,'shape':list(g.shape),'lengths':list(g.lengths),'backend':e.kind};latest=folder/'latest.npz'
 if latest.exists():
  s=restore(latest,e,ident);need(sha(folder/'history.json')==(folder/'history.sha256').read_text().strip(),'History seal changed');h=load(folder/'history.json')
 else:
  if fine:cs,_,provenance=fine_q5()
  else:
   cs,provenance=endpoint(key,key.startswith('q5'))
   if key.startswith('q5'):cs=Engine('cpu').state(cs['n']);cs['iteration']=50
  s=adapt_state(cs,e);s.update(observe_spacing=5,next_observe=s['iteration']+5);del cs;h=[{'recorded_at':stamp(),'iteration':s['iteration'],**metrics(e.host(s['n']),g)}];e.audit(s['n'],g);checkpoint(latest,s,e,ident);save_history(folder,h);shutil.copy2(latest,folder/'initial.npz');save(folder/'import.json',{'recorded_at':stamp(),'source':provenance,'backend':e.kind,'optimizer_continuation':'matching Q5 restart of conjugacy/alpha on both grids' if key.startswith('q5') else 'all retained optimizer arrays and alpha preserved; backend migration explicit and disposable-step qualified','new_observation_schedule':'both residuals and representation margin; does not alter step method'})
 if h[-1]['iteration']!=s['iteration']:h.append({'recorded_at':stamp(),'iteration':s['iteration'],'recovered_checkpoint_observation':True,**metrics(e.host(s['n']),g)});save_history(folder,h)
 spacing=s.get('observe_spacing') or 5;reason=None;allocation='budget_exhausted_unresolved';next_observe=s.get('next_observe') or s['iteration']+spacing
 try:
  while s['iteration']<start+maximum:
   last=h[-1]
   if not representation(last,seed['q'],GATES):allocation='deferred_representation_loss';break
   if stationary(last,seed['q'],GATES):allocation='measured_static_survivor_pending_mesh_confirmation' if last['tail_fraction']<=GATES['initial_tail_limit'] else 'measured_stationary_boundary_followup';break
   if s['iteration']>=start+base and (s['iteration']-start)%50==0 and not key.startswith('q5'):
    allowed,details=contingency(h,start);save(folder/('contingency-'+str(s['iteration'])+'.json'),{'recorded_at':stamp(),'allowed':allowed,**details})
    if not allowed:allocation='deferred_no_recent_joint_progress';break
   target=min(start+maximum,((s['iteration']-start)//50+1)*50+start)
   save(out/'status.json',{'recorded_at':stamp(),'status':'working','pid':os.getpid(),'seed':label,'native_iteration':s['iteration'],'batch_target':target,'maximum_additional_steps':maximum})
   while s['iteration']<target:
    guard();accepted,step=e.step(s,g)
    if not accepted:reason=step;allocation='deferred_solver_stall';break
    if s['iteration']>=next_observe or s['iteration']==target:
     e.sync();m=metrics(e.host(s['n']),g);audit=e.audit(s['n'],g,GATES['qualification_rtol'],GATES['qualification_atol']);h.append({'recorded_at':stamp(),'iteration':s['iteration'],**m,'backend_audit':audit,'optimizer_alpha':s['alpha'],'step':{k:float(v) if isinstance(v,(np.floating,)) else v for k,v in step.items()}});spacing,why=observation_interval(h,spacing,seed['q']);next_observe=s['iteration']+spacing;s.update(observe_spacing=spacing,next_observe=next_observe);checkpoint(latest,s,e,ident);save_history(folder,h);save(folder/'next-observation.json',{'recorded_at':stamp(),'spacing':spacing,'reasons':why,'next_iteration':next_observe});log('Candidate observation',seed=label,iteration=s['iteration'],joint_gate_multiple=proximity(m),spacing=spacing)
     if not representation(m,seed['q'],GATES) or stationary(m,seed['q'],GATES):break
   checkpoint(latest,s,e,ident)
   if h[-1]['iteration']!=s['iteration']:h.append({'recorded_at':stamp(),'iteration':s['iteration'],**metrics(e.host(s['n']),g)});save_history(folder,h)
   stage=folder/('stage-'+str(s['iteration']).zfill(4)+'.npz');shutil.copy2(latest,stage)
   if reason:break
  final=h[-1]
  if not representation(final,seed['q'],GATES):allocation='deferred_representation_loss'
  elif stationary(final,seed['q'],GATES):allocation='measured_static_survivor_pending_mesh_confirmation' if final['tail_fraction']<=GATES['initial_tail_limit'] else 'measured_stationary_boundary_followup'
  save(folder/'relationships.json',curve_fits(h))
  item={'recorded_at':stamp(),'seed':key,'label':label,'nodes':g.shape[0],'length':23.04,'backend':e.kind,'native_start_iteration':start,'iteration':s['iteration'],'additional_steps':s['iteration']-start,'maximum_additional_steps':maximum,'allocation_status':allocation,'reason':reason,'metrics':final,'checkpoint':latest.relative_to(out).as_posix(),'checkpoint_sha256':sha(latest),'whole_Q_rejected':False,'history':h};save(summary,item);summary.with_suffix('.sha256').write_text(sha(summary)+'\n');return item
 except BaseException:
  checkpoint(latest,s,e,ident);save_history(folder,h);raise
 finally:del s,e;gc.collect()

def report(results):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 import html,base64,csv
 fig,axes=plt.subplots(2,2,figsize=(12,9),layout='constrained')
 for ax,v in zip(axes.flat,results):
  h=v['history'];x=[r['iteration']-v['native_start_iteration'] for r in h];ax.semilogy(x,[r['relative_force_l2']/1e-4 for r in h],'-o',markersize=2,label='force / gate');ax.semilogy(x,[r['acceleration_max']/1e-3 for r in h],'-s',markersize=2,label='acceleration / gate');ax.axhline(1,color='green',linestyle='--');ax.set_title(v['label']);ax.set_xlabel('Added optimizer steps');ax.grid(alpha=.2)
 axes.flat[0].legend();fig.savefig(out/'histories.png',dpi=200);plt.close(fig)
 table=[{'seed':v['label'],'nodes':v['nodes'],'added_steps':v['additional_steps'],'allocation':v['allocation_status'],'force':v['metrics']['relative_force_l2'],'acceleration':v['metrics']['acceleration_max'],'tail':v['metrics']['tail_fraction']} for v in results]
 with (out/'measurements.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
 text='<!doctype html><html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Targeted Q diagnostics</title><style>body{font:16px/1.6 system-ui;max-width:1200px;margin:25px auto;padding:15px}img{max-width:100%}pre{white-space:pre-wrap;overflow-wrap:anywhere}td,th{padding:8px;border-bottom:1px solid #ddd}table{border-collapse:collapse}</style><h1>Targeted Q diagnostics and bounded continuation</h1><p>'+html.escape(json.dumps(stamp()))+'</p><p>Unchanged neutral static D4 model; optimizer steps are not physical time. Q4/Q6 receive read-only diagnostics. Q7/Q9 remain deferred. Q5 restarts both resolutions from native iteration 50. Endpoint secants justify allocation caps only, not a passing-time prediction.</p><table><tr>'+''.join('<th>'+k+'</th>' for k in table[0])+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row.values())+'</tr>' for row in table)+'</table>'
 for path in [out/'histories.png']+sorted((out/'diagnostics').glob('*.png')):text+='<h2>'+html.escape(path.stem)+'</h2><img src="data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()+'">'
 text+='<h2>Retained-field diagnosis</h2><pre>'+html.escape((out/'diagnostics.json').read_text())+'</pre><h2>Allocation basis</h2><pre>'+html.escape((ROOT/'BUDGET-BASIS.json').read_text())+'</pre></html>';(out/'REPORT.html').write_text(text)

def seal_output():
 shutil.copytree(ROOT,out/'handover',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
 full=[{'path':f.relative_to(out).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size} for f in out.rglob('*.npz')];save(out/'field-manifest.json',{'recorded_at':stamp(),'files':full,'scope':'New full fields stay local; parent fields unchanged at recorded source paths; compact ZIP excludes NPZ'})
 excluded={'worker.lock','SHA256SUMS','evidence.zip','runner.log','status.json','heartbeat.json','launch.json'}
 payload=[f for f in out.rglob('*') if f.is_file() and f.suffix not in ['.npz','.tmp'] and f.name not in (excluded-{'SHA256SUMS'}) and f!=out/'SHA256SUMS']
 (out/'SHA256SUMS').write_text(''.join(sha(f)+'  '+f.relative_to(out).as_posix()+'\n' for f in sorted(payload)))
 with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(payload)+[out/'SHA256SUMS']:z.write(f,f.relative_to(out))

def run():
 source_verify(False)
 if (out/'record.json').exists() and load(out/'record.json').get('status')=='complete_pending_review' and (out/'evidence.zip').is_file() and (out/'REPORT.html').is_file():log('Already complete',output=str(out));return
 need((out/'preflight.json').is_file() and sha(out/'preflight.json')==(out/'preflight.sha256').read_text().strip(),'Run preflight/benchmark first')
 receipt=load(out/'preflight.json');need(receipt['identity']==identity(),'Preflight identity changed; use a new output allocation')
 results=[]
 for key,label,maximum,base,fine in [('q8-trefoil32-1-2','q8-continuation',300,150,False),('q10-trefoil32-2-2','q10-continuation',200,100,False),('q5-trefoil32-1-1','q5-coarse-restart',50,50,False),('q5-trefoil32-1-1','q5-fine-restart',50,50,True)]:results.append(branch_job(key,label,maximum,base,receipt,fine))
 source_verify(True);record={'recorded_at':stamp(),'status':'complete_pending_review','identity':receipt['identity'],'plan':PLAN,'results':results,'q4_q6_relaxation_steps':0,'deferrals':[{'seed':s,'allocation_status':'explicitly_deferred_pending_diagnostics','whole_Q_rejected':False} for s in PLAN['deferred']],'additional_steps':sum(v['additional_steps'] for v in results),'maximum_additional_steps':600,'motion_cases':0,'parent_fields_verified_unchanged':True,'static_readiness':[v['label'] for v in results if v['allocation_status']=='measured_static_survivor_pending_mesh_confirmation']};save(out/'record.json',record);report(results);seal_output();save(out/'status.json',{'recorded_at':stamp(),'status':'complete_pending_review','additional_steps':record['additional_steps'],'evidence':str(out/'evidence.zip'),'report':str(out/'REPORT.html')});log('Analysis complete pending review',output=str(out))

stop=threading.Event()
def pulse():
 while not stop.wait(15):save(out/'heartbeat.json',{'recorded_at':stamp(),'pid':os.getpid()})
def interrupt(*_):raise KeyboardInterrupt('Graceful stop requested; latest optimizer state retained')
signal.signal(signal.SIGTERM,interrupt);save(out/'heartbeat.json',{'recorded_at':stamp(),'pid':os.getpid()});threading.Thread(target=pulse,daemon=True).start()
try:
 verify_package();guard()
 if a.mode=='preflight':
  source_verify(False)
  if (out/'preflight.json').exists():need(load(out/'preflight.json')['identity']==identity(),'Existing preflight identity changed');need(sha(out/'preflight.json')==(out/'preflight.sha256').read_text().strip(),'Preflight seal changed');log('Matching preflight receipt retained')
  else:
   save(out/'status.json',{'recorded_at':stamp(),'status':'preflight_working','pid':os.getpid()});preflight();save(out/'status.json',{'recorded_at':stamp(),'status':'preflight_passed','pid':os.getpid()})
 else:run()
except BaseException as ex:
 save(out/'status.json',{'recorded_at':stamp(),'status':'interrupted' if isinstance(ex,KeyboardInterrupt) else 'failed','pid':os.getpid(),'error':str(ex)});traceback.print_exc();raise
finally:stop.set()

"""Local-only numerical handover. No GitHub or repository mutations."""
import argparse,os,subprocess,sys,secrets,signal,zipfile
from pathlib import Path
from datetime import datetime,timezone
from support import *
p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['verify','preflight','benchmark','run','resume','status','stop']);p.add_argument('--repo',type=Path,default=Path.home()/'ElectronFieldTopology-rapid-q-followup');p.add_argument('--source-run',type=Path);p.add_argument('--output',type=Path);p.add_argument('--backend',choices=['auto','cpu','cuda'],default='auto');a=p.parse_args()
def alive(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False

def busy():
 parents={os.getpid()};pid=os.getppid()
 while pid>1 and pid not in parents:
  parents.add(pid)
  try:pid=int(next(v.split()[1] for v in (Path('/proc')/str(pid)/'status').read_text().splitlines() if v.startswith('PPid:')))
  except (FileNotFoundError,PermissionError,StopIteration):break
 found=[]
 for path in Path('/proc').iterdir():
  if not path.name.isdigit() or int(path.name) in parents:continue
  try:
   if path.stat().st_uid!=os.getuid():continue
   args=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');exe=args.split(' ',1)[0]
   if ('python' in exe or exe.endswith('/uv')) and any(t in args for t in ['screen_worker.py','followup_worker.py','sf_candidate_survey','sf_temporal_run','run_measurements.py','run_calibration.py',str(ROOT/'worker.py')]):found.append(int(path.name))
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 need(not found,'Another analysis worker is active; leave it running and retry later: '+str(found))

def main():
 package=verify_package()
 if a.mode=='verify':
  need(sha(ROOT/'data/parent-evidence.zip')==load(ROOT/'PLAN.json')['parent_sha256'],'Parent evidence changed')
  with zipfile.ZipFile(ROOT/'data/parent-evidence.zip') as z:
   need(z.testzip() is None,'Parent ZIP CRC failure')
   for line in z.read('SHA256SUMS').decode().splitlines():
    h,n=line.split('  ',1);need(__import__('hashlib').sha256(z.read(n)).hexdigest()==h,'Parent compact hash mismatch')
  log('Package and parent compact evidence verified',production_started=False);return
 repo=a.repo.resolve();need((repo/'pyproject.toml').is_file(),'Repository not found; set --repo to the prepared follow-up checkout')
 base=repo/'artifacts/targeted-q-diagnostic';base.mkdir(parents=True,exist_ok=True);pointer=base/'LATEST-20261115.json'
 if a.output:out=a.output.resolve()
 elif pointer.exists():
  selected=load(pointer);need(selected['package_sha256']==package,'Previous allocation uses another package; choose a new --output path');out=Path(selected['output'])
 elif a.mode in ['preflight','benchmark']:
  rid=datetime.now(timezone.utc).strftime('%Y%m%dt%H%M%Sz-')+secrets.token_hex(4);out=base/rid
 else:raise RuntimeError('Run preflight first, or supply the existing --output path')
 if a.mode in ['status','stop']:
  status=load(out/'status.json') if (out/'status.json').exists() else {};heartbeat=load(out/'heartbeat.json') if (out/'heartbeat.json').exists() else {};launch=load(out/'launch.json') if (out/'launch.json').exists() else {}
  running=False;pid=None
  for candidate in [heartbeat.get('pid'),status.get('pid'),launch.get('pid')]:
   if not candidate or not alive(candidate):continue
   try:
    proc=Path('/proc')/str(candidate);cmdline=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode()
    if proc.stat().st_uid==os.getuid() and str(ROOT/'worker.py') in cmdline and str(out) in cmdline:running=True;pid=candidate;break
   except (FileNotFoundError,PermissionError):pass
  if a.mode=='stop':
   if running:os.kill(pid,signal.SIGTERM);log('Graceful stop requested',pid=pid,output=str(out))
   else:log('No matching analysis worker is running',output=str(out))
  else:log('Analysis status',runner_alive=running,output=str(out),status=status,heartbeat=heartbeat,report=str(out/'REPORT.html'),evidence=str(out/'evidence.zip'))
  return
 busy()
 source=a.source_run
 if source is None:
  rid=load(ROOT/'PLAN.json')['parent_run'];candidates=[]
  for root in [repo,Path.home()/'ElectronFieldTopology-rapid-q-followup',Path.home()/'ElectronFieldTopology-rapid-q-screen',Path.home()/'ElectronFieldTopology-repository-admin']:
   if root.exists():candidates.extend(root.glob('artifacts/*/'+rid));candidates.extend(root.glob('artifacts/*/*/'+rid))
  candidates=sorted({v.resolve() for v in candidates if (v/'evidence.zip').is_file()})
  need(len(candidates)==1,'Supply --source-run with the exact completed 20261114t132254z-9e6c35d4 directory; candidates: '+str(candidates));source=candidates[0]
 source=source.resolve();out.mkdir(parents=True,exist_ok=True)
 config={'package_sha256':package,'repo':str(repo),'source_run':str(source),'backend':a.backend}
 if (out/'allocation.json').exists():need(load(out/'allocation.json')==config,'Allocation configuration differs; use its original paths/backend or choose a new --output')
 else:need(not any(out.iterdir()),'Output is not empty and has no allocation identity');save(out/'allocation.json',config)
 save(pointer,{'recorded_at':stamp(),'package_sha256':package,'output':str(out)})
 env=os.environ.copy()
 for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:env[k]='4'
 mode='preflight' if a.mode in ['preflight','benchmark'] else 'run'
 argv=['uv','run','--frozen','--python','3.12.14']
 if a.backend!='cpu':argv+=['--extra','gpu']
 argv+=['python',str(ROOT/'worker.py'),mode,'--repo',str(repo),'--source-run',str(source),'--output',str(out),'--backend',a.backend]
 if mode=='preflight':
  result=subprocess.run(argv,cwd=repo,env=env);need(result.returncode==0,'Local preflight stopped; inspect output and status');log('Preflight complete; run may now be launched',output=str(out));return
 need((out/'preflight.json').is_file(),'Run preflight first')
 if (out/'record.json').is_file() and load(out/'record.json').get('status')=='complete_pending_review' and (out/'evidence.zip').exists():log('Already complete',output=str(out));return
 with (out/'runner.log').open('a') as log_file:child=subprocess.Popen(argv,cwd=repo,env=env,stdout=log_file,stderr=subprocess.STDOUT,start_new_session=True)
 save(out/'launch.json',{'recorded_at':stamp(),'pid':child.pid,'argv':argv});log('Background analysis launched',pid=child.pid,output=str(out),log=str(out/'runner.log'))
try:main()
except Exception as ex:log('Handover stopped',error=str(ex));sys.exit(1)

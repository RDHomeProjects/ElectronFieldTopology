from pathlib import Path
import sys,ast,tempfile,json,shutil,math,numpy as np
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root))
from support import *
from analysis import spatial_summary,curve_fits
# Analytic array check: unit-z field projects away the z component of raw gradient.
n=np.zeros((13,)*3+(3,));n[...,2]=1;raw=np.zeros_like(n);raw[...,0]=2;raw[...,2]=99;fixed=np.ones((13,)*3,bool);fixed[2:-2,2:-2,2:-2]=False
r,mag=spatial_summary(n,raw,(.5,)*3,fixed)
assert np.allclose(mag[~fixed],2) and np.all(mag[fixed]==0)
assert abs(r['gradient_power_fraction_shell_width2']+r['gradient_power_fraction_core']-1)<1e-12
h=[{'iteration':i,'relative_force_l2':.01*math.exp(-.02*i),'acceleration_max':.1*math.exp(-.02*i)} for i in range(0,101,5)]
f=curve_fits(h);assert f['relative_force_l2']['models'][0]['model']=='exponential' and f['relative_force_l2']['models'][0]['normalized_holdout_RMSE']<1e-10
ok,_=contingency(h,0);assert ok
flat=[{'iteration':i,'relative_force_l2':.01,'acceleration_max':.1} for i in range(0,151,5)];assert not contingency(flat,0)[0]
rev=[{'iteration':i,'relative_force_l2':f,'acceleration_max':f,'hopf_integral':-8,'minimum_corner_cone':.8} for i,f in [(0,.02),(10,.01),(20,.02)]];assert observation_interval(rev,10,8)[0]<10
# Exercise the production branch control flow with deterministic test engine.
tree=ast.parse((root/'worker.py').read_text());selected=[v for v in tree.body if isinstance(v,ast.FunctionDef) and v.name in ['save_history','branch_job']]
class Grid:
 def __init__(self,shape,lengths,mode):self.shape=shape;self.lengths=lengths
class Engine:
 def __init__(self,*args):pass
 kind='cpu';xp=np
 def state(self,n):return {'n':n.copy(),'iteration':50,'alpha':1.,'old_g':None,'old_z':None,'direction':None}
 def host(self,n):return n.copy()
 def sync(self):pass
 def audit(self,*args):return {'passed':True}
 def step(self,s,g):
  
  if case.get('interrupt_at')==s['iteration']:
   case.pop('interrupt_at');raise KeyboardInterrupt('simulated interruption')
  s['iteration']+=1;s['n'][0]=s['iteration'];return True,{'energy':1.,'objective_calls':2}
def checkpoint(path,s,e,ident):
 with Path(path).open('wb') as f:np.savez(f,**{k:v for k,v in s.items() if v is not None})
def restore(path,e,ident):
 with np.load(path) as z:return {k:(z[k].copy() if k=='n' else float(z[k]) if k=='alpha' else int(z[k])) for k in z.files}
case={'kind':'success'}
def metrics(n,g):
 i=float(n[0]);q=case.get('q',8);start=300 if q==8 else 100 if q==10 else 50
 d=i-start
 if case['kind']=='flat':force,accel=.01,.1
 elif case['kind']=='slow':force,accel=.01*math.exp(-.002*d),.1*math.exp(-.002*d)
 else:force,accel=(.000364*math.exp(-.01559*d),.00622*math.exp(-.01446*d)) if q==8 else (.00787*math.exp(-.05838*d),.288*math.exp(-.04719*d)) if q==10 else (.07,.73)
 hopf=-q if q!=5 or d<45 else -4.68
 return {'relative_force_l2':force,'acceleration_max':accel,'hopf_integral':hopf,'minimum_corner_cone':.8,'unit_error':0.,'tail_fraction':.0001}
def representation(m,q,p):return abs(abs(m['hopf_integral'])-q)/q<=.05
def stationary(m,q,p):return representation(m,q,p) and m['relative_force_l2']<=1e-4 and m['acceleration_max']<=1e-3
def endpoint(key,start=False):
 q=rows[key]['q'];i=300 if q==8 else 100 if q==10 else 50;return {'n':np.array([float(i)]),'iteration':i,'alpha':1.,'old_g':None,'old_z':None,'direction':None},{'fixture':True}
rows={k:{'seed':{'q':q,'id':k},'q':q,'iteration':i,'nodes':nodes} for k,q,i,nodes in [('q8-trefoil32-1-2',8,300,121),('q10-trefoil32-2-2',10,100,145),('q5-trefoil32-1-1',5,95,97)]}
g=globals().copy();g.update({'GATES':{'initial_tail_limit':.00075,'qualification_rtol':2e-10,'qualification_atol':2e-11},'engine_for':lambda *args:Engine(),'adapt_state':lambda s,e:s.copy(),'guard':lambda:None,'gc':__import__('gc'),'log':lambda *args,**kw:None})
exec(compile(ast.Module(body=selected,type_ignores=[]),'production-branch-under-test','exec'),g)
results=[]
with tempfile.TemporaryDirectory() as td:
 g['out']=Path(td)
 for q,key,label,maxi,base,kind in [(8,'q8-trefoil32-1-2','q8',300,150,'success'),(10,'q10-trefoil32-2-2','q10',200,100,'success'),(8,'q8-trefoil32-1-2','q8-flat',300,150,'flat'),(5,'q5-trefoil32-1-1','q5-loss',50,50,'success')]:
  case.update(q=q,kind=kind);r=g['branch_job'](key,label,maxi,base,{'identity':{}})
  if kind=='flat':assert r['additional_steps']==150 and r['allocation_status']=='deferred_no_recent_joint_progress'
  elif q==5:assert r['additional_steps']==45 and r['allocation_status']=='deferred_representation_loss'
  else:assert r['additional_steps']<=maxi and r['allocation_status']=='measured_static_survivor_pending_mesh_confirmation'
  again=g['branch_job'](key,label,maxi,base,{'identity':{}});assert again['checkpoint_sha256']==r['checkpoint_sha256'];results.append({k:r[k] for k in ['label','additional_steps','allocation_status']})
with tempfile.TemporaryDirectory() as td:
 g['out']=Path(td);case.update(q=8,kind='slow')
 r=g['branch_job']('q8-trefoil32-1-2','q8-hard-cap',300,150,{'identity':{}});assert r['additional_steps']==300 and r['allocation_status']=='budget_exhausted_unresolved';results.append({k:r[k] for k in ['label','additional_steps','allocation_status']})
 case.update(q=8,kind='success',interrupt_at=303)
 try:g['branch_job']('q8-trefoil32-1-2','q8-resume',300,150,{'identity':{}})
 except KeyboardInterrupt:pass
 else:raise AssertionError('Expected test interruption')
 r=g['branch_job']('q8-trefoil32-1-2','q8-resume',300,150,{'identity':{}});assert r['additional_steps']<=300 and r['allocation_status']=='measured_static_survivor_pending_mesh_confirmation';results.append({k:r[k] for k in ['label','additional_steps','allocation_status']})
validation={'recorded_at':stamp(),'status':'passed','array_tests':['projected gradient removes normal component','fixed layers excluded','core/shell power partition','exponential chronological fit recovers analytic trend','progress/plateau contingency','adaptive reversal sampling'],'production_control_flow_tests':results,'limitations':['Control-flow fixture uses a deterministic substitute engine, not the production D4 solver.','No CUDA device or full zbook fields available on host; actual D4 source hashes, field replay, CPU/GPU parity and timings are mandatory local preflight checks.']}
print(json.dumps(validation,indent=2))

# Targeted Q analysis — local zbook handover

A standalone numerical run package. It reads the existing prepared follow-up checkout and retained fields, writes a separate artifact directory and does not contact GitHub. PR75 already recorded the preceding outcomes; this campaign produces evidence for a later local publication handover. No existing records, source files or field files are overwritten. uv may synchronize its local environment from the unchanged frozen lock.

## Launch

```bash
unzip -n "$HOME/Downloads/ElectronFieldTopology-next-analysis-20261115.zip" -d "$HOME/Downloads"
package="$HOME/Downloads/ElectronFieldTopology-next-analysis-20261115"
(
  set -euo pipefail
  bash "$package/RUN.sh" verify
  bash "$package/RUN.sh" preflight --backend auto
  bash "$package/RUN.sh" run --backend auto
  bash "$package/RUN.sh" status
)
```

Preflight runs in the foreground and can take several minutes. It hashes and CRC-checks all 29 parent NPZ files, replays selected metrics on CPU, creates Q4/Q6 diagnostics, and benchmarks CPU/CUDA disposable steps. Production launches in the background only after this succeeds. No fixed wall-time cap is imposed. `benchmark` is an alias for the complete preflight, not a shortcut around field checks.

The default source checkout is `$HOME/ElectronFieldTopology-rapid-q-followup`. The package finds the exact parent `20261114t132254z-9e6c35d4` beneath the known EFT checkout artifact directories. If it cannot resolve exactly one match, supply the complete path:

```bash
bash "$package/RUN.sh" preflight --backend auto --source-run "/absolute/path/to/20261114t132254z-9e6c35d4"
bash "$package/RUN.sh" run --backend auto --source-run "/absolute/path/to/20261114t132254z-9e6c35d4"
```

Use `--repo /absolute/path` consistently if the prepared checkout has a different location. To start another independent allocation use an unused `--output /absolute/path` on preflight and every subsequent command. Otherwise commands reuse the latest allocation pointer under the selected repo's `artifacts/targeted-q-diagnostic` directory. Configuration and package hashes must match on resume.

For CPU only, replace `--backend auto` with `--backend cpu` on BOTH preflight and run/resume. For mandatory CUDA use `--backend cuda`; qualification failure stops that allocation. Changing backend requests requires a new output directory and new preflight.

## Allocation and sequence

| Work | Grid and box | Additional accepted production steps |
|---|---|---:|
| Q4 axial22 / Q6 axial | Their retained grids, box 23.04 | **0**; retained-state diagnosis only |
| Q8 trefoil | 121³, box 23.04 | 150 base + up to 150 contingent; maximum **300** |
| Q10 variant | 145³, box 23.04 | 100 base + up to 100 contingent; maximum **200** |
| Q5 coarse control | 97³, box 23.04 | Maximum **50** from retained native iteration 50 |
| Q5 finer test | 121³, box 23.04 | Maximum **50**, same pre-loss parent field |
| Q7 / Q9 | Retained as-is | **0**, explicitly deferred |

Total maximum is **600 new accepted production steps**. At most 50 steps occur in a batch. Unused allocations are not redistributed. There is no new Q4/Q6 relaxation, domain/scale change, action change, optimizer-method comparison or motion in this campaign.

Q8's previous endpoint log-decay secants suggest about 83 further force steps and 126 acceleration steps; Q10 suggests about 75 and 120. The supplied BUDGET-BASIS.json gives the calculations. Noisy, correlated observations and weak earlier holdouts do not validate those crossing predictions. These values justify planning caps only. Linear, quadratic, constant and exponential chronological fits are reported independently for force and acceleration.

After the base allocation, every additional 50-step batch requires either a ≥20% reduction in the current joint gate multiple relative to this run's start, or a ≥10% improvement in the best joint multiple in the recent 100-step window versus the preceding 100-step window. No recent progress yields explicit deferral. Thus the maxima are available budgets, not promises that all steps will run.

## Scientific controls

All original gates remain unchanged: force ≤1e-4, acceleration ≤1e-3, approximate Hopf-magnitude relative error ≤5%, positive corner cone, unit error <1e-10 and rest-tail fraction ≤0.00075 using shell width2.0. Both stationarity limits and representation are required; tail failure remains a separate boundary follow-up. Stop production at measured stationarity, representation loss or a solver stall. No threshold is inferred from a fitted curve. Static survivors queue for later mesh/domain/boost/motion admission, which is not executed here.

The original projected Sobolev-CG/Armijo step, float64 action, fixed boundary and 200-iteration restart rule are retained. Q8/Q10 retain all optimizer arrays, alpha and native iteration. A qualified CPU/GPU migration is explicitly recorded if selected; no mid-branch fallback occurs. New observation scheduling does not change the step algorithm.

Observations adapt to force AND acceleration reversals, log-curve curvature sign changes, prediction discrepancies, proximity to stationarity, and Q5 representation margins. Intervals range from1 to20 accepted steps; Q5 uses at most5, tightening to1 when its approximate charge error reaches3% or its cone narrows below0.5. Batch endpoints are always observed. These are measurement triggers, not new acceptance thresholds. Parent histories are retained in the included original compact archive.

Q5 starts from the exact retained `followup-start.npz`, native iteration50, not the failed iteration95 endpoint. Coarse and fine runs both restart conjugacy and alpha at native count50. Fine resolution uses the existing cubic sampler, normalizes, applies the fixed boundary and records all corrections, metrics and gates before evolution. Holding the common seed field, box and restart rule fixed controls the resolution comparison. The parent Q5 tail already fails its boundary gate; finer resolution alone is not assumed to repair this.

Q4/Q6 diagnostics include retained start and stored batch endpoints, raw projected static-gradient maps, residual concentration in core/boundary shell, DST high-frequency power, optimizer alpha, periodic restart state and direction/gradient alignment. These fields are not relaxed. The projected gradient map is not the model acceleration field. Its spectrum does not prove a numerical floor or physical instability. Comparisons are within each retained mesh; no cross-mesh energy ranking is introduced.

## Hardware qualification and resources

Uses Python3.12.14 via uv with frozen dependencies and four CPU threads. CPU is used for all gate metrics, spatial diagnostics and gradient audits. For each production configuration, three disposable CPU steps and up to three disposable CUDA steps test acceptance and field agreement; the latter two timings provide a median after warm-up. Auto selects qualified CUDA only if its step speedup is at least1.2. Otherwise the branch uses CPU, recording the reason. CUDA's D4 energy/gradient must match CPU at the existing tolerances; one-step fields must agree at rtol2e-9/atol2e-10. Q5 finer-grid checks use the actual interpolated field. These disposable controls are excluded from the600-step production budget and are counted in the qualification receipt.

No CUDA performance is claimed from host tests. Qualification timings describe step cost, not whole-run speed including CPU diagnostic overhead. Keep at least12GiB disk free and4GiB host RAM available; checks stop and preserve fields if reserves are reached. Avoid concurrent EFT campaigns. There is also an exclusive per-output worker lock.

## Monitor, stop and resume

```bash
bash "$package/RUN.sh" status
bash "$package/RUN.sh" stop
bash "$package/RUN.sh" resume --backend auto
```

Status provides UTC/Melbourne timestamps, heartbeat, log, report and evidence paths. Stop sends SIGTERM only to the matching worker, which writes its optimizer checkpoint. Wait until status shows it is no longer alive before resume. Use the same backend and any custom repo/output/source arguments. Parent fields stay untouched. Unexpected shutdown can replay steps since the last sealed checkpoint; final accepted-step allocation never exceeds declared caps. If a checkpoint/history seal is incomplete after abrupt power loss, preserve it for assessment rather than deleting the run.

## Outputs and assessment

On completion: `REPORT.html` is self-contained and opens directly in a browser. It embeds measured history plots and high-resolution diagnostic maps. Additional artifacts include measurements.csv, diagnostics.json, per-job histories/optimizer checkpoints/fit comparisons, Q5 interpolation metrics, preflight receipt, explicit Q7/Q9 deferrals, run identity and field-manifest.json.

Upload the new **evidence.zip** for assessment after status is `complete_pending_review`. It includes compact records, reports, code/plan and parent compact evidence. Full NPZ fields stay local and are listed with hashes; do not remove the source runs or treat compact evidence as their backup.

Host validation covers analytic arrays, chronological curve fits and the production branch control flow using a substitute deterministic engine, including early stops, progress-based extensions, hard caps and interrupted-run recovery. Actual full-field replay, D4 CPU/GPU parity and timing must pass the zbook preflight. There is no electron-physics, continuum stability or final knot certificate implied by completion.
